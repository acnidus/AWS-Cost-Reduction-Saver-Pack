# AWS Cost Saver Pack - Package Summary

## 🎯 Overview

The AWS Cost Saver Pack is a comprehensive collection of scripts and tools designed to automatically reduce AWS costs by managing idle resources, cleaning up unused storage, and providing detailed cost monitoring and reporting.

## 📦 What's Included

### Core Scripts
1. **`stop_idle_instances.py`** - Automatically stops idle EC2 instances based on CPU and network usage
2. **`clean_unused_ebs.sh`** - Removes unattached EBS volumes that are older than specified days
3. **`daily_cost_report.py`** - Generates and sends daily AWS cost reports via email
4. **`cleanup_snapshots.py`** - Manages old EBS snapshots to reduce storage costs
5. **`optimize_rds.py`** - Stops non-production RDS instances during off-hours
6. **`cost_alert.py`** - Monitors costs and sends alerts when thresholds are exceeded

### Configuration & Documentation
- **`config/config.yaml`** - Comprehensive configuration file with all settings
- **`config/email_template.html`** - Professional HTML email template for reports
- **`README.md`** - Main documentation and quick start guide
- **`docs/SETUP.md`** - Detailed setup instructions
- **`docs/CONFIGURATION.md`** - Complete configuration reference
- **`docs/TROUBLESHOOTING.md`** - Common issues and solutions

### Deployment & Automation
- **`Dockerfile`** - Containerized deployment
- **`docker-compose.yml`** - Easy container orchestration
- **`cron/cron_examples.txt`** - Automated execution examples
- **`quick_start.sh`** - Automated setup script
- **`requirements.txt`** - Python dependencies

## 🚀 Key Features

### Safety & Protection
- **Dry-run mode** for testing before production use
- **Resource tagging** to prevent accidental modification of critical resources
- **Whitelist/blacklist** systems for fine-grained control
- **Confirmation prompts** for destructive operations
- **Rollback capabilities** for major changes

### Cost Optimization
- **Intelligent idle detection** using CloudWatch metrics
- **Automated resource scheduling** based on business hours
- **Storage cleanup** for unused volumes and snapshots
- **Database optimization** for non-production RDS instances
- **Cost threshold monitoring** with automated alerts

### Monitoring & Reporting
- **Comprehensive logging** with rotation and archiving
- **Email notifications** with professional HTML templates
- **Cost breakdown analysis** by service and region
- **Savings estimation** and tracking
- **Performance metrics** and execution summaries

### Automation & Integration
- **Cron job automation** for scheduled execution
- **Docker containerization** for easy deployment
- **AWS API integration** with rate limiting and retry logic
- **Multi-account support** through AWS profiles
- **Environment-specific configurations**

## 💰 Expected Cost Savings

Based on typical enterprise usage patterns:

| Resource Type | Potential Savings | Implementation |
|---------------|-------------------|----------------|
| **EC2 Instances** | 20-40% | Stop idle instances during off-hours |
| **EBS Volumes** | 15-25% | Remove unused and old volumes |
| **EBS Snapshots** | 10-20% | Clean up old snapshots |
| **RDS Instances** | 30-50% | Stop non-production databases |
| **Overall AWS Bill** | **15-30%** | Combined optimization strategies |

## 🛠️ Technical Requirements

### Prerequisites
- **Python 3.7+** with pip
- **AWS CLI** configured with appropriate permissions
- **Linux/macOS/Windows** (with WSL for Windows)
- **Minimum 512MB RAM** and 100MB storage

### AWS Permissions
The scripts require the following IAM permissions:
- `ec2:DescribeInstances`, `ec2:StopInstances`
- `ec2:DescribeVolumes`, `ec2:DeleteVolume`
- `ec2:DescribeSnapshots`, `ec2:DeleteSnapshot`
- `ce:GetCostAndUsage` (Cost Explorer)
- `rds:DescribeDBInstances`, `rds:StopDBInstance`
- `logs:DescribeLogGroups`, `logs:DeleteLogGroup`

### Python Dependencies
- **boto3** - AWS SDK for Python
- **PyYAML** - YAML configuration parsing
- **Jinja2** - HTML template rendering
- **requests** - HTTP client for notifications
- **Additional utilities** for logging and scheduling

## 🔧 Installation Options

### Option 1: Quick Start (Recommended)
```bash
# Download and run the quick start script
chmod +x quick_start.sh
./quick_start.sh
```

### Option 2: Manual Installation
```bash
# Install dependencies
pip install -r requirements.txt

# Configure AWS credentials
aws configure

# Edit configuration
nano config/config.yaml

# Test scripts
python3 scripts/stop_idle_instances.py --dry-run
```

### Option 3: Docker Deployment
```bash
# Build and run with Docker Compose
docker-compose up -d

# Or build manually
docker build -t aws-cost-saver .
docker run -v ~/.aws:/root/.aws aws-cost-saver
```

## 📋 Configuration Highlights

### EC2 Management
```yaml
ec2:
  idle_threshold_hours: 24        # Hours before considering idle
  cpu_threshold_percent: 5        # CPU utilization threshold
  network_threshold_mb: 10        # Network activity threshold
  excluded_tags:                  # Protected resources
    - "Environment=Production"
    - "AutoStop=false"
```

### EBS Cleanup
```yaml
ebs:
  max_unattached_days: 7          # Days before deletion
  excluded_volume_types:          # Protected volume types
    - "gp3"
    - "io2"
  backup_before_delete: true      # Safety feature
```

### Cost Monitoring
```yaml
cost:
  alert_threshold_usd: 100       # Daily cost alert
  monthly_alert_threshold_usd: 1000  # Monthly threshold
  alert_recipients:               # Notification targets
    - "admin@company.com"
    - "finance@company.com"
```

### RDS Optimization
```yaml
rds:
  stop_hours:
    start: "18:00"                # 6 PM
    end: "08:00"                  # 8 AM
  timezone: "America/New_York"    # Business hours
  production_tags:                # Protected databases
    - "Environment=Production"
```

## 🔄 Automation Examples

### Daily Schedule
```bash
# 2 AM - Stop idle instances
0 2 * * * python3 scripts/stop_idle_instances.py

# 3 AM - Clean EBS volumes
0 3 * * * bash scripts/clean_unused_ebs.sh

# 8 AM - Daily cost report
0 8 * * * python3 scripts/daily_cost_report.py

# 9 AM - Cost monitoring
0 9 * * * python3 scripts/cost_alert.py
```

### Weekly Operations
```bash
# Sunday 4 AM - Cleanup snapshots
0 4 * * 0 python3 scripts/cleanup_snapshots.py

# Monday 10 AM - Weekly summary
0 10 * * 1 python3 scripts/weekly_summary.py
```

### Business Hours
```bash
# Weekdays 6 PM - Stop RDS instances
0 18 * * 1-5 python3 scripts/optimize_rds.py --action stop

# Weekdays 8 AM - Start RDS instances
0 8 * * 1-5 python3 scripts/optimize_rds.py --action start
```

## 📊 Monitoring & Logging

### Log Structure
```
logs/
├── stop_idle_instances_20240101_020000.log
├── clean_unused_ebs_20240101_030000.log
├── daily_cost_report_20240101_080000.log
├── execution_summary_20240101_020000.json
├── cost_report_20240101_080000.json
└── cost_alert_summary_20240101_090000.json
```

### Key Metrics Tracked
- **Resources managed** (instances, volumes, snapshots)
- **Cost savings** (estimated and actual)
- **Execution time** and performance
- **Error rates** and failure analysis
- **API call counts** and rate limiting

### Email Reports Include
- **Cost breakdown** by service and region
- **Resource optimization** summaries
- **Savings estimates** and projections
- **Recommendations** for further optimization
- **Alert notifications** for cost spikes

## 🚨 Safety Features

### Resource Protection
- **Tag-based exclusions** for critical resources
- **Environment detection** (dev/staging/prod)
- **Business hours** respect for production systems
- **Backup creation** before destructive operations
- **Confirmation prompts** for major changes

### Error Handling
- **Graceful degradation** when services are unavailable
- **Retry logic** with exponential backoff
- **Comprehensive logging** for debugging
- **Rollback procedures** for failed operations
- **Alert notifications** for critical failures

### Testing & Validation
- **Dry-run mode** for all scripts
- **Configuration validation** before execution
- **Resource existence** verification
- **Permission checking** before operations
- **Safe defaults** for all settings

## 🔗 Integration Possibilities

### AWS Services
- **CloudWatch** for metrics and monitoring
- **SNS** for notifications and alerts
- **Lambda** for serverless execution
- **Step Functions** for workflow orchestration
- **Systems Manager** for automation

### External Tools
- **Slack** for team notifications
- **Microsoft Teams** for enterprise communication
- **Discord** for community alerts
- **PagerDuty** for incident management
- **Jira** for ticket creation

### Monitoring Platforms
- **Grafana** for dashboards
- **Prometheus** for metrics collection
- **Datadog** for APM integration
- **New Relic** for performance monitoring
- **Splunk** for log analysis

## 📈 Scaling & Performance

### Large Environment Support
- **Batch processing** for thousands of resources
- **Parallel execution** for faster processing
- **Pagination handling** for AWS API limits
- **Rate limiting** to respect AWS quotas
- **Resource batching** for efficient operations

### Performance Optimization
- **Connection pooling** for AWS clients
- **Caching strategies** for repeated data
- **Async operations** where applicable
- **Memory management** for large datasets
- **Progress tracking** for long operations

## 🔒 Security Considerations

### Access Control
- **Least privilege** IAM policies
- **Role-based access** control
- **Environment isolation** for different accounts
- **Credential rotation** support
- **Audit logging** for all operations

### Data Protection
- **Encryption at rest** for logs and configs
- **Secure communication** with AWS APIs
- **Sensitive data masking** in logs
- **Access logging** for configuration changes
- **Backup encryption** for snapshots

## 🆘 Support & Maintenance

### Troubleshooting
- **Comprehensive error messages** with solutions
- **Debug logging** for detailed analysis
- **Health checks** for system monitoring
- **Performance metrics** for optimization
- **Common issues** documentation

### Maintenance
- **Log rotation** and archiving
- **Configuration backups** and versioning
- **Dependency updates** and security patches
- **Performance monitoring** and tuning
- **Regular testing** and validation

## 🎉 Getting Started

### 1. Quick Setup
```bash
# Download the package
git clone <repository-url>
cd AWS_Cost_Saver_Pack

# Run the quick start script
./quick_start.sh
```

### 2. Test Everything
```bash
# Test in dry-run mode
python3 scripts/stop_idle_instances.py --dry-run
bash scripts/clean_unused_ebs.sh --dry-run
python3 scripts/daily_cost_report.py --no-email
```

### 3. Configure for Production
```bash
# Edit configuration
nano config/config.yaml

# Set up automation
crontab -e

# Monitor execution
tail -f logs/*.log
```

### 4. Monitor and Optimize
- Review cost savings reports
- Adjust thresholds based on usage patterns
- Set up additional alerting
- Optimize execution schedules
- Scale for larger environments

## 📞 Support Resources

- **Documentation**: Comprehensive guides in `docs/` directory
- **Examples**: Sample configurations and cron jobs
- **Troubleshooting**: Common issues and solutions
- **Logs**: Detailed execution information
- **Community**: Share experiences and improvements

## 👨‍💻 Creator & Support

**Tool created by:** [acnid.al@gmail.com](mailto:acnid.al@gmail.com)

If you find this tool helpful and want to support its development:

**[Buy Me a Coffee ☕](https://buymeacoffee.com/acnidal)**

Your support helps maintain and improve this project for the community!

---

**The AWS Cost Saver Pack provides enterprise-grade cost optimization with safety, automation, and comprehensive monitoring. Start saving money on AWS today! 💰**
