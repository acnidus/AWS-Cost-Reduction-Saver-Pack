#!/usr/bin/env python3
"""
AWS Cost Saver - Stop Idle EC2 Instances
Automatically stops EC2 instances that have been idle for a specified period.

Author: AWS Cost Saver Pack
Version: 1.0.0
Tool created by: acnid.al@gmail.com
Support the project: https://buymeacoffee.com/acnidal
"""

import boto3
import yaml
import logging
import argparse
import sys
from datetime import datetime, timedelta
from botocore.exceptions import ClientError, NoCredentialsError
import json
import os

class IdleInstanceManager:
    def __init__(self, config_path='../config/config.yaml'):
        """Initialize the IdleInstanceManager with configuration."""
        self.config = self.load_config(config_path)
        self.setup_logging()
        self.ec2_client = None
        self.cloudwatch_client = None
        self.setup_aws_clients()
        
    def load_config(self, config_path):
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            print(f"Configuration file not found: {config_path}")
            sys.exit(1)
        except yaml.YAMLError as e:
            print(f"Error parsing configuration file: {e}")
            sys.exit(1)
    
    def setup_logging(self):
        """Setup logging configuration."""
        log_dir = '../logs'
        os.makedirs(log_dir, exist_ok=True)
        
        log_file = f"{log_dir}/stop_idle_instances_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        
        logging.basicConfig(
            level=getattr(logging, self.config.get('logging', {}).get('level', 'INFO')),
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info("Idle Instance Manager initialized")
    
    def setup_aws_clients(self):
        """Setup AWS clients."""
        try:
            session = boto3.Session(
                region_name=self.config['aws']['region'],
                profile_name=self.config['aws']['profile']
            )
            self.ec2_client = session.client('ec2')
            self.cloudwatch_client = session.client('cloudwatch')
            self.logger.info(f"AWS clients initialized for region: {self.config['aws']['region']}")
        except NoCredentialsError:
            self.logger.error("AWS credentials not found. Please run 'aws configure'")
            sys.exit(1)
        except Exception as e:
            self.logger.error(f"Error setting up AWS clients: {e}")
            sys.exit(1)
    
    def get_instance_metrics(self, instance_id, hours_back=24):
        """Get CloudWatch metrics for an instance."""
        try:
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(hours=hours_back)
            
            # Get CPU utilization
            cpu_response = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/EC2',
                MetricName='CPUUtilization',
                Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                StartTime=start_time,
                EndTime=end_time,
                Period=3600,  # 1 hour
                Statistics=['Average']
            )
            
            # Get network in/out
            network_in_response = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/EC2',
                MetricName='NetworkIn',
                Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                StartTime=start_time,
                EndTime=end_time,
                Period=3600,
                Statistics=['Sum']
            )
            
            network_out_response = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/EC2',
                MetricName='NetworkOut',
                Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                StartTime=start_time,
                EndTime=end_time,
                Period=3600,
                Statistics=['Sum']
            )
            
            # Calculate averages
            cpu_values = [point['Average'] for point in cpu_response['Datapoints']]
            network_in_values = [point['Sum'] for point in network_in_response['Datapoints']]
            network_out_values = [point['Sum'] for point in network_out_response['Datapoints']]
            
            avg_cpu = sum(cpu_values) / len(cpu_values) if cpu_values else 0
            avg_network_in = sum(network_in_values) / len(network_in_values) if network_in_values else 0
            avg_network_out = sum(network_out_values) / len(network_out_values) if network_out_values else 0
            
            return {
                'cpu_utilization': avg_cpu,
                'network_in_mb': avg_network_in / (1024 * 1024),  # Convert to MB
                'network_out_mb': avg_network_out / (1024 * 1024)  # Convert to MB
            }
            
        except Exception as e:
            self.logger.warning(f"Could not get metrics for instance {instance_id}: {e}")
            return None
    
    def is_instance_idle(self, instance, metrics):
        """Determine if an instance is idle based on metrics and configuration."""
        if not metrics:
            return False
            
        ec2_config = self.config['ec2']
        
        # Check CPU threshold
        if metrics['cpu_utilization'] > ec2_config['cpu_threshold_percent']:
            return False
            
        # Check network threshold
        total_network = metrics['network_in_mb'] + metrics['network_out_mb']
        if total_network > ec2_config['network_threshold_mb']:
            return False
            
        # Check if instance has been running for the idle threshold
        launch_time = instance['LaunchTime']
        running_time = datetime.now(launch_time.tzinfo) - launch_time
        idle_threshold = timedelta(hours=ec2_config['idle_threshold_hours'])
        
        if running_time < idle_threshold:
            return False
            
        return True
    
    def should_exclude_instance(self, instance):
        """Check if instance should be excluded based on tags."""
        if 'Tags' not in instance:
            return False
            
        excluded_tags = self.config['ec2']['excluded_tags']
        instance_tags = {tag['Key']: tag['Value'] for tag in instance['Tags']}
        
        for excluded_tag in excluded_tags:
            key, value = excluded_tag.split('=')
            if instance_tags.get(key) == value:
                self.logger.info(f"Instance {instance['InstanceId']} excluded due to tag: {excluded_tag}")
                return True
                
        return False
    
    def get_running_instances(self):
        """Get all running EC2 instances."""
        try:
            response = self.ec2_client.describe_instances(
                Filters=[
                    {'Name': 'instance-state-name', 'Values': ['running']}
                ]
            )
            
            instances = []
            for reservation in response['Reservations']:
                instances.extend(reservation['Instances'])
                
            self.logger.info(f"Found {len(instances)} running instances")
            return instances
            
        except ClientError as e:
            self.logger.error(f"Error getting instances: {e}")
            return []
    
    def stop_instance(self, instance_id, reason):
        """Stop an EC2 instance."""
        try:
            if not self.config['ec2']['dry_run']:
                response = self.ec2_client.stop_instances(InstanceIds=[instance_id])
                self.logger.info(f"Stopped instance {instance_id}: {reason}")
                return True
            else:
                self.logger.info(f"[DRY RUN] Would stop instance {instance_id}: {reason}")
                return True
                
        except ClientError as e:
            self.logger.error(f"Error stopping instance {instance_id}: {e}")
            return False
    
    def run(self):
        """Main execution method."""
        self.logger.info("Starting idle instance detection and management")
        
        # Get running instances
        instances = self.get_running_instances()
        if not instances:
            self.logger.info("No running instances found")
            return
        
        stopped_count = 0
        total_savings = 0
        
        for instance in instances:
            instance_id = instance['InstanceId']
            instance_type = instance['InstanceType']
            
            # Check if instance should be excluded
            if self.should_exclude_instance(instance):
                continue
            
            # Get instance metrics
            metrics = self.get_instance_metrics(instance_id)
            if not metrics:
                continue
            
            # Check if instance is idle
            if self.is_instance_idle(instance, metrics):
                reason = f"CPU: {metrics['cpu_utilization']:.1f}%, Network: {metrics['network_in_mb'] + metrics['network_out_mb']:.1f}MB"
                
                if self.stop_instance(instance_id, reason):
                    stopped_count += 1
                    # Estimate savings (rough calculation)
                    estimated_hourly_cost = self.estimate_instance_cost(instance_type)
                    total_savings += estimated_hourly_cost
        
        self.logger.info(f"Process completed. Stopped {stopped_count} instances.")
        if stopped_count > 0:
            self.logger.info(f"Estimated daily savings: ${total_savings * 24:.2f}")
        
        # Save execution summary
        self.save_execution_summary(stopped_count, total_savings)
    
    def estimate_instance_cost(self, instance_type):
        """Estimate hourly cost for an instance type (rough estimation)."""
        # This is a simplified cost estimation
        # In production, you might want to use AWS Pricing API
        cost_map = {
            't3.micro': 0.0104,
            't3.small': 0.0208,
            't3.medium': 0.0416,
            't3.large': 0.0832,
            'm5.large': 0.096,
            'm5.xlarge': 0.192,
            'c5.large': 0.085,
            'c5.xlarge': 0.17,
        }
        
        return cost_map.get(instance_type, 0.10)  # Default to $0.10/hour
    
    def save_execution_summary(self, stopped_count, total_savings):
        """Save execution summary to a JSON file."""
        summary = {
            'timestamp': datetime.now().isoformat(),
            'stopped_instances': stopped_count,
            'estimated_daily_savings': total_savings * 24,
            'estimated_hourly_savings': total_savings,
            'config_used': {
                'idle_threshold_hours': self.config['ec2']['idle_threshold_hours'],
                'cpu_threshold_percent': self.config['ec2']['cpu_threshold_percent'],
                'network_threshold_mb': self.config['ec2']['network_threshold_mb'],
                'dry_run': self.config['ec2']['dry_run']
            }
        }
        
        log_dir = '../logs'
        summary_file = f"{log_dir}/execution_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(summary_file, 'w') as f:
                json.dump(summary, f, indent=2)
            self.logger.info(f"Execution summary saved to: {summary_file}")
        except Exception as e:
            self.logger.error(f"Error saving execution summary: {e}")

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='Stop idle EC2 instances to save costs')
    parser.add_argument('--config', '-c', default='../config/config.yaml',
                       help='Path to configuration file')
    parser.add_argument('--dry-run', action='store_true',
                       help='Run in dry-run mode (no actual changes)')
    
    args = parser.parse_args()
    
    try:
        manager = IdleInstanceManager(args.config)
        
        # Override dry-run setting if specified via command line
        if args.dry_run:
            manager.config['ec2']['dry_run'] = True
            manager.logger.info("Running in DRY-RUN mode")
        
        manager.run()
        
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
