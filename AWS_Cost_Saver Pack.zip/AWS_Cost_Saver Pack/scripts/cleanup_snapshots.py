#!/usr/bin/env python3
"""
AWS Cost Saver - Cleanup Old EBS Snapshots
Automatically removes old EBS snapshots to save storage costs.

Author: AWS Cost Saver Pack
Version: 1.0.0
Tool created by: acnid.al@gmail.com
Support the project: https://buymeacoffee.com/acnidal
"""

import boto3
import yaml
import logging
import argparse
import sys
from datetime import datetime, timedelta
from botocore.exceptions import ClientError, NoCredentialsError
import json
import os

class SnapshotCleanupManager:
    def __init__(self, config_path='../config/config.yaml'):
        """Initialize the SnapshotCleanupManager with configuration."""
        self.config = self.load_config(config_path)
        self.setup_logging()
        self.ec2_client = None
        self.setup_aws_clients()
        
    def load_config(self, config_path):
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            print(f"Configuration file not found: {config_path}")
            sys.exit(1)
        except yaml.YAMLError as e:
            print(f"Error parsing configuration file: {e}")
            sys.exit(1)
    
    def setup_logging(self):
        """Setup logging configuration."""
        log_dir = '../logs'
        os.makedirs(log_dir, exist_ok=True)
        
        log_file = f"{log_dir}/cleanup_snapshots_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        
        logging.basicConfig(
            level=getattr(logging, self.config.get('logging', {}).get('level', 'INFO')),
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info("Snapshot Cleanup Manager initialized")
    
    def setup_aws_clients(self):
        """Setup AWS clients."""
        try:
            session = boto3.Session(
                region_name=self.config['aws']['region'],
                profile_name=self.config['aws']['profile']
            )
            self.ec2_client = session.client('ec2')
            self.logger.info(f"AWS EC2 client initialized for region: {self.config['aws']['region']}")
        except NoCredentialsError:
            self.logger.error("AWS credentials not found. Please run 'aws configure'")
            sys.exit(1)
        except Exception as e:
            self.logger.error(f"Error setting up AWS clients: {e}")
            sys.exit(1)
    
    def get_snapshots(self):
        """Get all EBS snapshots owned by self."""
        try:
            response = self.ec2_client.describe_snapshots(
                OwnerIds=['self']
            )
            
            snapshots = response['Snapshots']
            self.logger.info(f"Found {len(snapshots)} snapshots owned by self")
            return snapshots
            
        except ClientError as e:
            self.logger.error(f"Error getting snapshots: {e}")
            return []
    
    def should_exclude_snapshot(self, snapshot):
        """Check if snapshot should be excluded from deletion."""
        # Check for critical tags
        if 'Tags' in snapshot:
            snapshot_tags = {tag['Key']: tag['Value'] for tag in snapshot['Tags']}
            
            # Exclude snapshots with critical tags
            critical_tags = ['Critical', 'Production', 'Backup', 'Keep']
            for tag_key in critical_tags:
                if tag_key in snapshot_tags and snapshot_tags[tag_key].lower() in ['true', 'production', 'critical']:
                    self.logger.info(f"Snapshot {snapshot['SnapshotId']} excluded due to tag: {tag_key}={snapshot_tags[tag_key]}")
                    return True
            
            # Exclude snapshots with specific names
            if 'Name' in snapshot_tags:
                name = snapshot_tags['Name'].lower()
                if any(keyword in name for keyword in ['backup', 'production', 'critical', 'keep']):
                    self.logger.info(f"Snapshot {snapshot['SnapshotId']} excluded due to name: {snapshot_tags['Name']}")
                    return True
        
        # Exclude snapshots that are in use by AMIs
        if 'Description' in snapshot and snapshot['Description']:
            desc = snapshot['Description'].lower()
            if 'ami' in desc or 'amazon' in desc:
                self.logger.info(f"Snapshot {snapshot['SnapshotId']} excluded - appears to be AMI-related")
                return True
        
        return False
    
    def get_old_snapshots(self, max_age_days=30):
        """Get snapshots older than specified days."""
        cutoff_date = datetime.now() - timedelta(days=max_age_days)
        old_snapshots = []
        
        snapshots = self.get_snapshots()
        
        for snapshot in snapshots:
            # Skip if snapshot should be excluded
            if self.should_exclude_snapshot(snapshot):
                continue
            
            # Check age
            start_time = snapshot['StartTime']
            if start_time.replace(tzinfo=None) < cutoff_date:
                old_snapshots.append(snapshot)
        
        self.logger.info(f"Found {len(old_snapshots)} old snapshots eligible for deletion")
        return old_snapshots
    
    def delete_snapshot(self, snapshot_id, reason):
        """Delete an EBS snapshot."""
        try:
            if not self.config.get('ebs', {}).get('dry_run', False):
                response = self.ec2_client.delete_snapshot(SnapshotId=snapshot_id)
                self.logger.info(f"Deleted snapshot {snapshot_id}: {reason}")
                return True
            else:
                self.logger.info(f"[DRY RUN] Would delete snapshot {snapshot_id}: {reason}")
                return True
                
        except ClientError as e:
            self.logger.error(f"Error deleting snapshot {snapshot_id}: {e}")
            return False
    
    def estimate_savings(self, snapshots):
        """Estimate cost savings from deleting snapshots."""
        total_size_gb = sum(snapshot['VolumeSize'] for snapshot in snapshots)
        
        # EBS snapshot storage costs approximately $0.05 per GB-month
        # Convert to daily savings
        monthly_cost = total_size_gb * 0.05
        daily_savings = monthly_cost / 30
        
        return {
            'total_size_gb': total_size_gb,
            'monthly_cost': monthly_cost,
            'daily_savings': daily_savings
        }
    
    def run(self):
        """Main execution method."""
        self.logger.info("Starting snapshot cleanup process")
        
        # Get configuration
        max_age_days = self.config.get('ebs', {}).get('max_snapshot_age_days', 30)
        dry_run = self.config.get('ebs', {}).get('dry_run', False)
        
        self.logger.info(f"Looking for snapshots older than {max_age_days} days")
        self.logger.info(f"Dry run mode: {dry_run}")
        
        # Get old snapshots
        old_snapshots = self.get_old_snapshots(max_age_days)
        
        if not old_snapshots:
            self.logger.info("No old snapshots found for deletion")
            return
        
        # Estimate savings
        savings = self.estimate_savings(old_snapshots)
        self.logger.info(f"Potential savings: ${savings['monthly_cost']:.2f}/month (${savings['daily_savings']:.2f}/day)")
        
        # Sort snapshots by age (oldest first)
        old_snapshots.sort(key=lambda x: x['StartTime'])
        
        # Delete snapshots
        deleted_count = 0
        failed_count = 0
        
        for snapshot in old_snapshots:
            snapshot_id = snapshot['SnapshotId']
            age_days = (datetime.now() - snapshot['StartTime'].replace(tzinfo=None)).days
            reason = f"Age: {age_days} days, Size: {snapshot['VolumeSize']}GB"
            
            if self.delete_snapshot(snapshot_id, reason):
                deleted_count += 1
            else:
                failed_count += 1
            
            # Small delay to avoid API throttling
            import time
            time.sleep(0.5)
        
        # Summary
        if dry_run:
            self.logger.info(f"[DRY RUN] Would delete {deleted_count} snapshots")
        else:
            self.logger.info(f"Snapshot cleanup completed: {deleted_count} deleted, {failed_count} failed")
        
        # Save execution summary
        self.save_execution_summary(deleted_count, failed_count, savings)
    
    def save_execution_summary(self, deleted_count, failed_count, savings):
        """Save execution summary to a JSON file."""
        summary = {
            'timestamp': datetime.now().isoformat(),
            'deleted_snapshots': deleted_count,
            'failed_deletions': failed_count,
            'savings': savings,
            'config_used': {
                'max_age_days': self.config.get('ebs', {}).get('max_snapshot_age_days', 30),
                'dry_run': self.config.get('ebs', {}).get('dry_run', False)
            }
        }
        
        log_dir = '../logs'
        summary_file = f"{log_dir}/snapshot_cleanup_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(summary_file, 'w') as f:
                json.dump(summary, f, indent=2)
            self.logger.info(f"Execution summary saved to: {summary_file}")
        except Exception as e:
            self.logger.error(f"Error saving execution summary: {e}")

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='Clean up old EBS snapshots to save costs')
    parser.add_argument('--config', '-c', default='../config/config.yaml',
                       help='Path to configuration file')
    parser.add_argument('--dry-run', action='store_true',
                       help='Run in dry-run mode (no actual deletions)')
    parser.add_argument('--max-age', type=int, default=30,
                       help='Maximum age in days for snapshots (default: 30)')
    
    args = parser.parse_args()
    
    try:
        manager = SnapshotCleanupManager(args.config)
        
        # Override configuration if specified via command line
        if args.dry_run:
            manager.config['ebs']['dry_run'] = True
            manager.logger.info("Running in DRY-RUN mode")
        
        if args.max_age != 30:
            manager.config['ebs']['max_snapshot_age_days'] = args.max_age
            manager.logger.info(f"Max age set to {args.max_age} days")
        
        manager.run()
        
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
