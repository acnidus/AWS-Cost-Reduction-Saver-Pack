#!/usr/bin/env python3
"""
AWS Cost Saver - Cost Alert Monitor
Monitors AWS costs and sends alerts when thresholds are exceeded.

Author: AWS Cost Saver Pack
Version: 1.0.0
Tool created by: acnid.al@gmail.com
Support the project: https://buymeacoffee.com/acnidal
"""

import boto3
import yaml
import logging
import argparse
import sys
import smtplib
import ssl
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from botocore.exceptions import ClientError, NoCredentialsError
import json
import os
import requests

class CostAlertMonitor:
    def __init__(self, config_path='../config/config.yaml'):
        """Initialize the CostAlertMonitor with configuration."""
        self.config = self.load_config(config_path)
        self.setup_logging()
        self.ce_client = None
        self.setup_aws_clients()
        
    def load_config(self, config_path):
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            print(f"Configuration file not found: {config_path}")
            sys.exit(1)
        except yaml.YAMLError as e:
            print(f"Error parsing configuration file: {e}")
            sys.exit(1)
    
    def setup_logging(self):
        """Setup logging configuration."""
        log_dir = '../logs'
        os.makedirs(log_dir, exist_ok=True)
        
        log_file = f"{log_dir}/cost_alert_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        
        logging.basicConfig(
            level=getattr(logging, self.config.get('logging', {}).get('level', 'INFO')),
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info("Cost Alert Monitor initialized")
    
    def setup_aws_clients(self):
        """Setup AWS clients."""
        try:
            session = boto3.Session(
                region_name=self.config['aws']['region'],
                profile_name=self.config['aws']['profile']
            )
            self.ce_client = session.client('ce')
            self.logger.info(f"AWS Cost Explorer client initialized for region: {self.config['aws']['region']}")
        except NoCredentialsError:
            self.logger.error("AWS credentials not found. Please run 'aws configure'")
            sys.exit(1)
        except Exception as e:
            self.logger.error(f"Error setting up AWS clients: {e}")
            sys.exit(1)
    
    def get_current_month_cost(self):
        """Get the current month's cost."""
        try:
            # Calculate date range for current month
            now = datetime.now()
            start_date = now.replace(day=1).strftime('%Y-%m-%d')
            end_date = now.strftime('%Y-%m-%d')
            
            response = self.ce_client.get_cost_and_usage(
                TimePeriod={
                    'Start': start_date,
                    'End': end_date
                },
                Granularity='MONTHLY',
                Metrics=['UnblendedCost']
            )
            
            if 'ResultsByTime' in response and response['ResultsByTime']:
                total_cost = float(response['ResultsByTime'][0]['Total']['UnblendedCost']['Amount'])
                return total_cost
            
            return 0
            
        except ClientError as e:
            self.logger.error(f"Error getting current month cost: {e}")
            return 0
    
    def get_daily_costs(self, days_back=7):
        """Get daily costs for the specified number of days."""
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            response = self.ce_client.get_cost_and_usage(
                TimePeriod={
                    'Start': start_date.strftime('%Y-%m-%d'),
                    'End': end_date.strftime('%Y-%m-%d')
                },
                Granularity='DAILY',
                Metrics=['UnblendedCost']
            )
            
            daily_costs = []
            if 'ResultsByTime' in response:
                for result in response['ResultsByTime']:
                    date = result['TimePeriod']['Start'][:10]
                    cost = float(result['Total']['UnblendedCost']['Amount'])
                    daily_costs.append({
                        'date': date,
                        'cost': cost
                    })
            
            return daily_costs
            
        except ClientError as e:
            self.logger.error(f"Error getting daily costs: {e}")
            return []
    
    def get_service_costs(self, days_back=7):
        """Get costs broken down by service."""
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            response = self.ce_client.get_cost_and_usage(
                TimePeriod={
                    'Start': start_date.strftime('%Y-%m-%d'),
                    'End': end_date.strftime('%Y-%m-%d')
                },
                Granularity='DAILY',
                Metrics=['UnblendedCost'],
                GroupBy=[
                    {'Type': 'DIMENSION', 'Key': 'SERVICE'}
                ]
            )
            
            service_costs = {}
            if 'ResultsByTime' in response:
                for result in response['ResultsByTime']:
                    for group in result['Groups']:
                        service = group['Keys'][0]
                        cost = float(group['Metrics']['UnblendedCost']['Amount'])
                        
                        if service not in service_costs:
                            service_costs[service] = 0
                        service_costs[service] += cost
            
            # Sort by cost (highest first)
            sorted_services = sorted(service_costs.items(), key=lambda x: x[1], reverse=True)
            return sorted_services
            
        except ClientError as e:
            self.logger.error(f"Error getting service costs: {e}")
            return []
    
    def check_cost_thresholds(self):
        """Check if costs exceed configured thresholds."""
        alerts = []
        cost_config = self.config.get('cost', {})
        
        # Check monthly threshold
        monthly_threshold = cost_config.get('monthly_alert_threshold_usd', 1000)
        current_month_cost = self.get_current_month_cost()
        
        if current_month_cost > monthly_threshold:
            alerts.append({
                'level': 'CRITICAL',
                'type': 'monthly_threshold',
                'message': f"Monthly costs (${current_month_cost:.2f}) exceed threshold (${monthly_threshold})",
                'current': current_month_cost,
                'threshold': monthly_threshold
            })
        
        # Check daily threshold
        daily_threshold = cost_config.get('alert_threshold_usd', 100)
        daily_costs = self.get_daily_costs(1)  # Last day
        
        if daily_costs:
            yesterday_cost = daily_costs[0]['cost']
            if yesterday_cost > daily_threshold:
                alerts.append({
                    'level': 'WARNING',
                    'type': 'daily_threshold',
                    'message': f"Daily costs (${yesterday_cost:.2f}) exceed threshold (${daily_threshold})",
                    'current': yesterday_cost,
                    'threshold': daily_threshold
                })
        
        # Check for unusual cost spikes
        daily_costs_week = self.get_daily_costs(7)
        if len(daily_costs_week) >= 3:
            costs = [day['cost'] for day in daily_costs_week]
            avg_cost = sum(costs) / len(costs)
            max_cost = max(costs)
            
            # Alert if any day is more than 3x the average
            if max_cost > avg_cost * 3:
                alerts.append({
                    'level': 'ALERT',
                    'type': 'cost_spike',
                    'message': f"Unusual cost spike detected: ${max_cost:.2f} (average: ${avg_cost:.2f})",
                    'current': max_cost,
                    'threshold': avg_cost * 3
                })
        
        return alerts
    
    def check_budget_alerts(self):
        """Check AWS Budgets for alerts."""
        try:
            budgets_client = boto3.client('budgets')
            
            response = budgets_client.describe_budgets(
                AccountId='self'
            )
            
            budget_alerts = []
            for budget in response['Budgets']:
                budget_name = budget['BudgetName']
                
                # Get budget notifications
                notifications = budgets_client.describe_notifications_for_budget(
                    AccountId='self',
                    BudgetName=budget_name
                )
                
                for notification in notifications['Notifications']:
                    if notification['NotificationType'] == 'ACTUAL':
                        threshold = notification['Threshold']
                        comparison_operator = notification['ComparisonOperator']
                        
                        # Check if threshold is exceeded
                        if comparison_operator == 'GREATER_THAN':
                            budget_alerts.append({
                                'level': 'BUDGET',
                                'type': 'budget_exceeded',
                                'message': f"Budget '{budget_name}' threshold exceeded: {threshold}%",
                                'budget': budget_name,
                                'threshold': threshold
                            })
            
            return budget_alerts
            
        except ClientError as e:
            self.logger.warning(f"Could not check AWS Budgets: {e}")
            return []
    
    def send_email_alert(self, alerts):
        """Send email alert with cost information."""
        email_config = self.config.get('email', {})
        
        if not email_config.get('username') or email_config.get('username') == 'your-email@gmail.com':
            self.logger.warning("Email not configured, skipping email alert")
            return False
        
        try:
            # Create email content
            subject = f"AWS Cost Alert - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            
            html_content = self.generate_alert_email(alerts)
            
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = email_config['from_address']
            msg['To'] = ', '.join(self.config['cost']['alert_recipients'])
            
            # Attach HTML content
            html_part = MIMEText(html_content, 'html')
            msg.attach(html_part)
            
            # Create SMTP connection
            context = ssl.create_default_context()
            
            with smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port']) as server:
                if email_config['use_tls']:
                    server.starttls(context=context)
                
                server.login(email_config['username'], email_config['password'])
                server.send_message(msg)
            
            self.logger.info("Cost alert email sent successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Error sending cost alert email: {e}")
            return False
    
    def generate_alert_email(self, alerts):
        """Generate HTML content for cost alert email."""
        html_content = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .alert {{ padding: 15px; margin: 10px 0; border-radius: 5px; }}
                .critical {{ background-color: #f8d7da; border-left: 4px solid #dc3545; }}
                .warning {{ background-color: #fff3cd; border-left: 4px solid #ffc107; }}
                .budget {{ background-color: #d1ecf1; border-left: 4px solid #17a2b8; }}
                .cost-summary {{ background-color: #d4edda; border-left: 4px solid #28a745; }}
                .metric {{ display: inline-block; margin: 10px; padding: 10px; background: white; border-radius: 5px; }}
                .metric-value {{ font-size: 24px; font-weight: bold; color: #dc3545; }}
            </style>
        </head>
        <body>
            <h1>🚨 AWS Cost Alert</h1>
            <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            
            <div class="cost-summary">
                <h2>💰 Current Cost Summary</h2>
                <div class="metric">
                    <div class="metric-value">${self.get_current_month_cost():.2f}</div>
                    <div>Current Month</div>
                </div>
            </div>
            
            <h2>⚠️ Active Alerts ({len(alerts)})</h2>
        """
        
        for alert in alerts:
            alert_class = alert['level'].lower()
            html_content += f"""
            <div class="alert {alert_class}">
                <h3>{alert['level']}: {alert['type'].replace('_', ' ').title()}</h3>
                <p>{alert['message']}</p>
            </div>
            """
        
        # Add cost breakdown
        service_costs = self.get_service_costs(7)
        if service_costs:
            html_content += """
            <h2>📊 Cost Breakdown (Last 7 Days)</h2>
            <table style="width: 100%; border-collapse: collapse;">
                <tr style="background-color: #f8f9fa;">
                    <th style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd;">Service</th>
                    <th style="padding: 8px; text-align: right; border-bottom: 1px solid #ddd;">Cost</th>
                </tr>
            """
            
            for service, cost in service_costs[:10]:  # Top 10 services
                html_content += f"""
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #ddd;">{service}</td>
                    <td style="padding: 8px; text-align: right; border-bottom: 1px solid #ddd;">${cost:.2f}</td>
                </tr>
                """
            
            html_content += "</table>"
        
        html_content += """
            <div style="margin-top: 30px; padding: 20px; background-color: #f8f9fa; border-radius: 5px;">
                <h3>🔧 Recommended Actions</h3>
                <ul>
                    <li>Review high-cost services and optimize usage</li>
                    <li>Check for unused or underutilized resources</li>
                    <li>Consider implementing cost controls and budgets</li>
                    <li>Review and adjust alert thresholds if needed</li>
                </ul>
            </div>
            
            <div style="margin-top: 20px; text-align: center; color: #666; font-size: 12px;">
                <p>This alert was generated automatically by AWS Cost Saver Pack</p>
                <p>Generated at """ + datetime.now().strftime('%H:%M:%S UTC') + """</p>
                <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;">
                <p style="font-size: 12px; color: #666;">
                    <strong>Tool created by:</strong> <a href="mailto:acnid.al@gmail.com" style="color: #667eea;">acnid.al@gmail.com</a><br>
                    <strong>Support the project:</strong> <a href="https://buymeacoffee.com/acnidal" style="color: #667eea;">Buy Me a Coffee ☕</a>
                </p>
            </div>
        </body>
        </html>
        """
        
        return html_content
    
    def send_slack_alert(self, alerts):
        """Send alert to Slack if configured."""
        slack_webhook = self.config.get('notifications', {}).get('slack_webhook', '')
        
        if not slack_webhook:
            return False
        
        try:
            # Prepare Slack message
            message = {
                "text": "🚨 AWS Cost Alert",
                "attachments": []
            }
            
            for alert in alerts:
                color_map = {
                    'CRITICAL': '#dc3545',
                    'WARNING': '#ffc107',
                    'ALERT': '#fd7e14',
                    'BUDGET': '#17a2b8'
                }
                
                attachment = {
                    "color": color_map.get(alert['level'], '#6c757d'),
                    "title": f"{alert['level']}: {alert['type'].replace('_', ' ').title()}",
                    "text": alert['message'],
                    "fields": [
                        {
                            "title": "Current Value",
                            "value": f"${alert['current']:.2f}",
                            "short": True
                        },
                        {
                            "title": "Threshold",
                            "value": f"${alert['threshold']:.2f}",
                            "short": True
                        }
                    ]
                }
                message["attachments"].append(attachment)
            
            # Send to Slack
            response = requests.post(slack_webhook, json=message)
            if response.status_code == 200:
                self.logger.info("Slack alert sent successfully")
                return True
            else:
                self.logger.error(f"Failed to send Slack alert: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error sending Slack alert: {e}")
            return False
    
    def run(self):
        """Main execution method."""
        self.logger.info("Starting cost alert monitoring")
        
        # Check cost thresholds
        cost_alerts = self.check_cost_thresholds()
        
        # Check budget alerts
        budget_alerts = self.check_budget_alerts()
        
        # Combine all alerts
        all_alerts = cost_alerts + budget_alerts
        
        if not all_alerts:
            self.logger.info("No cost alerts detected")
            return
        
        self.logger.info(f"Found {len(all_alerts)} cost alerts")
        
        # Log alerts
        for alert in all_alerts:
            self.logger.warning(f"{alert['level']}: {alert['message']}")
        
        # Send notifications
        email_sent = self.send_email_alert(all_alerts)
        slack_sent = self.send_slack_alert(all_alerts)
        
        # Save alert summary
        self.save_alert_summary(all_alerts, email_sent, slack_sent)
        
        # Print summary to console
        self.print_alert_summary(all_alerts)
    
    def save_alert_summary(self, alerts, email_sent, slack_sent):
        """Save alert summary to a JSON file."""
        summary = {
            'timestamp': datetime.now().isoformat(),
            'alerts': alerts,
            'notifications': {
                'email_sent': email_sent,
                'slack_sent': slack_sent
            },
            'cost_data': {
                'current_month': self.get_current_month_cost(),
                'daily_costs': self.get_daily_costs(7),
                'service_costs': dict(self.get_service_costs(7))
            }
        }
        
        log_dir = '../logs'
        summary_file = f"{log_dir}/cost_alert_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(summary_file, 'w') as f:
                json.dump(summary, f, indent=2)
            self.logger.info(f"Alert summary saved to: {summary_file}")
        except Exception as e:
            self.logger.error(f"Error saving alert summary: {e}")
    
    def print_alert_summary(self, alerts):
        """Print alert summary to console."""
        print("\n" + "="*60)
        print("AWS COST ALERT SUMMARY")
        print("="*60)
        
        print(f"Current Month Cost: ${self.get_current_month_cost():.2f}")
        print(f"Active Alerts: {len(alerts)}")
        
        for alert in alerts:
            print(f"\n{alert['level']}: {alert['message']}")
        
        print("="*60)

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='Monitor AWS costs and send alerts')
    parser.add_argument('--config', '-c', default='../config/config.yaml',
                       help='Path to configuration file')
    parser.add_argument('--no-email', action='store_true',
                       help='Run without sending email alerts')
    parser.add_argument('--no-slack', action='store_true',
                       help='Run without sending Slack alerts')
    
    args = parser.parse_args()
    
    try:
        monitor = CostAlertMonitor(args.config)
        
        if args.no_email:
            monitor.config['email']['username'] = None
            monitor.logger.info("Running in no-email mode")
        
        if args.no_slack:
            monitor.config['notifications']['slack_webhook'] = ''
            monitor.logger.info("Running in no-slack mode")
        
        monitor.run()
        
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
