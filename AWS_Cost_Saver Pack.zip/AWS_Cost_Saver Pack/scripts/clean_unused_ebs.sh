#!/bin/bash

# AWS Cost Saver - Clean Unused EBS Volumes
# Automatically removes unattached EBS volumes to save storage costs
#
# Author: AWS Cost Saver Pack
# Version: 1.0.0
# License: MIT
# Tool created by: acnid.al@gmail.com
# Support the project: https://buymeacoffee.com/acnidal

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/../config/config.yaml"
LOG_DIR="${SCRIPT_DIR}/../logs"
DRY_RUN=false
MAX_UNATTACHED_DAYS=7
EXCLUDED_VOLUME_TYPES=("gp3" "io2")
REQUIRE_CONFIRMATION=true
MAX_VOLUMES_PER_RUN=100

# Create log directory if it doesn't exist
mkdir -p "$LOG_DIR"

# Log file
LOG_FILE="${LOG_DIR}/clean_unused_ebs_$(date +%Y%m%d_%H%M%S).log"

# Function to log messages
log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case "$level" in
        "INFO")
            echo -e "${BLUE}[INFO]${NC} $message" | tee -a "$LOG_FILE"
            ;;
        "WARN")
            echo -e "${YELLOW}[WARN]${NC} $message" | tee -a "$LOG_FILE"
            ;;
        "ERROR")
            echo -e "${RED}[ERROR]${NC} $message" | tee -a "$LOG_FILE"
            ;;
        "SUCCESS")
            echo -e "${GREEN}[SUCCESS]${NC} $message" | tee -a "$LOG_FILE"
            ;;
    esac
}

# Function to check if AWS CLI is installed
check_aws_cli() {
    if ! command -v aws &> /dev/null; then
        log "ERROR" "AWS CLI is not installed. Please install it first."
        exit 1
    fi
    
    # Check AWS credentials
    if ! aws sts get-caller-identity &> /dev/null; then
        log "ERROR" "AWS credentials not configured. Please run 'aws configure' first."
        exit 1
    fi
    
    log "INFO" "AWS CLI and credentials verified"
}

# Function to load configuration from YAML (basic parsing)
load_config() {
    if [[ -f "$CONFIG_FILE" ]]; then
        log "INFO" "Loading configuration from $CONFIG_FILE"
        
        # Extract EBS configuration (basic YAML parsing)
        if grep -q "max_unattached_days:" "$CONFIG_FILE"; then
            MAX_UNATTACHED_DAYS=$(grep "max_unattached_days:" "$CONFIG_FILE" | awk '{print $2}')
        fi
        
        if grep -q "dry_run:" "$CONFIG_FILE"; then
            DRY_RUN=$(grep "dry_run:" "$CONFIG_FILE" | awk '{print $2}')
        fi
        
        if grep -q "require_confirmation:" "$CONFIG_FILE"; then
            REQUIRE_CONFIRMATION=$(grep "require_confirmation:" "$CONFIG_FILE" | awk '{print $2}')
        fi
        
        log "INFO" "Configuration loaded: MAX_UNATTACHED_DAYS=$MAX_UNATTACHED_DAYS, DRY_RUN=$DRY_RUN"
    else
        log "WARN" "Configuration file not found, using default values"
    fi
}

# Function to get AWS region
get_aws_region() {
    local region
    region=$(aws configure get region 2>/dev/null || echo "us-east-1")
    echo "$region"
}

# Function to check if volume should be excluded
should_exclude_volume() {
    local volume_type="$1"
    local volume_id="$2"
    
    # Check excluded volume types
    for excluded_type in "${EXCLUDED_VOLUME_TYPES[@]}"; do
        if [[ "$volume_type" == "$excluded_type" ]]; then
            log "INFO" "Volume $volume_id excluded due to type: $volume_type"
            return 0
        fi
    done
    
    # Check for critical tags
    local critical_tags
    critical_tags=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$volume_id" "Name=key,Values=Critical,Environment" --query 'Tags[?Value==`Production` || Value==`Critical` || Value==`true`].Key' --output text 2>/dev/null || echo "")
    
    if [[ -n "$critical_tags" ]]; then
        log "INFO" "Volume $volume_id excluded due to critical tags: $critical_tags"
        return 0
    fi
    
    return 1
}

# Function to get unattached volumes
get_unattached_volumes() {
    local region="$1"
    
    log "INFO" "Searching for unattached EBS volumes in region: $region"
    
    # Get all volumes
    local volumes_json
    volumes_json=$(aws ec2 describe-volumes \
        --region "$region" \
        --filters "Name=status,Values=available" \
        --query 'Volumes[?State==`available`].[VolumeId,Size,VolumeType,CreatedTime,State]' \
        --output json 2>/dev/null || echo "[]")
    
    if [[ "$volumes_json" == "[]" ]]; then
        log "INFO" "No unattached volumes found"
        return 0
    fi
    
    # Parse JSON and filter by age
    local current_time
    current_time=$(date +%s)
    local cutoff_time
    cutoff_time=$((current_time - MAX_UNATTACHED_DAYS * 24 * 3600))
    
    local volumes_to_delete=()
    local total_size=0
    
    # Use jq if available, otherwise basic parsing
    if command -v jq &> /dev/null; then
        while IFS= read -r line; do
            if [[ -n "$line" ]]; then
                local volume_id size volume_type created_time state
                read -r volume_id size volume_type created_time state <<< "$line"
                
                # Convert created time to timestamp
                local created_timestamp
                created_timestamp=$(date -d "$created_time" +%s 2>/dev/null || echo "0")
                
                if [[ $created_timestamp -lt $cutoff_time ]]; then
                    if ! should_exclude_volume "$volume_type" "$volume_id"; then
                        volumes_to_delete+=("$volume_id")
                        total_size=$((total_size + size))
                        log "INFO" "Volume $volume_id (${size}GB, $volume_type) marked for deletion"
                    fi
                fi
            fi
        done < <(echo "$volumes_json" | jq -r '.[] | @tsv')
    else
        log "WARN" "jq not available, using basic volume filtering"
        # Basic parsing without jq
        local volume_ids
        volume_ids=$(aws ec2 describe-volumes \
            --region "$region" \
            --filters "Name=status,Values=available" \
            --query 'Volumes[?State==`available`].VolumeId' \
            --output text 2>/dev/null || echo "")
        
        for volume_id in $volume_ids; do
            if [[ -n "$volume_id" ]]; then
                local volume_info
                volume_info=$(aws ec2 describe-volumes \
                    --region "$region" \
                    --volume-ids "$volume_id" \
                    --query 'Volumes[0].[Size,VolumeType,CreatedTime]' \
                    --output text 2>/dev/null || echo "")
                
                if [[ -n "$volume_info" ]]; then
                    read -r size volume_type created_time <<< "$volume_info"
                    local created_timestamp
                    created_timestamp=$(date -d "$created_time" +%s 2>/dev/null || echo "0")
                    
                    if [[ $created_timestamp -lt $cutoff_time ]]; then
                        if ! should_exclude_volume "$volume_type" "$volume_id"; then
                            volumes_to_delete+=("$volume_id")
                            total_size=$((total_size + size))
                            log "INFO" "Volume $volume_id (${size}GB, $volume_type) marked for deletion"
                        fi
                    fi
                fi
            fi
        done
    fi
    
    # Limit number of volumes per run
    if [[ ${#volumes_to_delete[@]} -gt $MAX_VOLUMES_PER_RUN ]]; then
        log "WARN" "Limiting deletion to $MAX_VOLUMES_PER_RUN volumes (found ${#volumes_to_delete[@]})"
        volumes_to_delete=("${volumes_to_delete[@]:0:$MAX_VOLUMES_PER_RUN}")
    fi
    
    if [[ ${#volumes_to_delete[@]} -eq 0 ]]; then
        log "INFO" "No volumes meet the criteria for deletion"
        return 0
    fi
    
    log "INFO" "Found ${#volumes_to_delete[@]} volumes to delete (total size: ${total_size}GB)"
    
    # Ask for confirmation if required
    if [[ "$REQUIRE_CONFIRMATION" == "true" && "$DRY_RUN" == "false" ]]; then
        echo
        echo -e "${YELLOW}The following volumes will be deleted:${NC}"
        for volume_id in "${volumes_to_delete[@]}"; do
            echo "  - $volume_id"
        done
        echo
        echo -e "${YELLOW}Total storage to be freed: ${total_size}GB${NC}"
        echo
        read -p "Do you want to continue? (yes/no): " -r confirm
        
        if [[ ! "$confirm" =~ ^[Yy][Ee][Ss]$ ]]; then
            log "INFO" "Operation cancelled by user"
            exit 0
        fi
    fi
    
    # Delete volumes
    local deleted_count=0
    local failed_count=0
    
    for volume_id in "${volumes_to_delete[@]}"; do
        if [[ "$DRY_RUN" == "true" ]]; then
            log "INFO" "[DRY RUN] Would delete volume: $volume_id"
            deleted_count=$((deleted_count + 1))
        else
            if aws ec2 delete-volume --region "$region" --volume-id "$volume_id" &> /dev/null; then
                log "SUCCESS" "Deleted volume: $volume_id"
                deleted_count=$((deleted_count + 1))
            else
                log "ERROR" "Failed to delete volume: $volume_id"
                failed_count=$((failed_count + 1))
            fi
        fi
        
        # Small delay to avoid API throttling
        sleep 1
    done
    
    # Summary
    if [[ "$DRY_RUN" == "true" ]]; then
        log "INFO" "[DRY RUN] Would delete $deleted_count volumes"
    else
        log "SUCCESS" "Operation completed: $deleted_count volumes deleted, $failed_count failed"
        log "INFO" "Estimated monthly savings: \$$((total_size * 8 / 1000)) (assuming $0.08/GB/month)"
    fi
    
    # Save execution summary
    save_execution_summary "$deleted_count" "$failed_count" "$total_size" "$region"
}

# Function to save execution summary
save_execution_summary() {
    local deleted_count="$1"
    local failed_count="$2"
    local total_size="$3"
    local region="$4"
    
    local summary_file="${LOG_DIR}/ebs_cleanup_summary_$(date +%Y%m%d_%H%M%S).json"
    
    cat > "$summary_file" << EOF
{
    "timestamp": "$(date -Iseconds)",
    "region": "$region",
    "deleted_volumes": $deleted_count,
    "failed_deletions": $failed_count,
    "total_storage_freed_gb": $total_size,
    "estimated_monthly_savings_usd": $((total_size * 8 / 1000)),
    "config": {
        "max_unattached_days": $MAX_UNATTACHED_DAYS,
        "dry_run": $DRY_RUN,
        "excluded_volume_types": [$(printf '"%s"' "${EXCLUDED_VOLUME_TYPES[@]}" | sed 's/ /","/g')]
    }
}
EOF
    
    log "INFO" "Execution summary saved to: $summary_file"
}

# Function to show help
show_help() {
    cat << EOF
Usage: $0 [OPTIONS]

AWS Cost Saver - Clean Unused EBS Volumes

OPTIONS:
    -h, --help              Show this help message
    -d, --dry-run          Run in dry-run mode (no actual deletions)
    -c, --config FILE      Configuration file path (default: ../config/config.yaml)
    -r, --region REGION    AWS region (default: from AWS config)
    -y, --yes              Skip confirmation prompt
    -m, --max-days DAYS    Maximum days a volume can be unattached (default: 7)

EXAMPLES:
    $0                      # Run with default settings
    $0 --dry-run           # Test run without deleting
    $0 --region us-west-2  # Run in specific region
    $0 --yes               # Skip confirmation

SAFETY FEATURES:
    - Excludes volumes with critical tags (Production, Critical, true)
    - Excludes specific volume types (gp3, io2)
    - Requires confirmation by default
    - Limits deletions per run
    - Comprehensive logging

EOF
}

# Main function
main() {
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -d|--dry-run)
                DRY_RUN=true
                shift
                ;;
            -c|--config)
                CONFIG_FILE="$2"
                shift 2
                ;;
            -r|--region)
                AWS_REGION="$2"
                shift 2
                ;;
            -y|--yes)
                REQUIRE_CONFIRMATION=false
                shift
                ;;
            -m|--max-days)
                MAX_UNATTACHED_DAYS="$2"
                shift 2
                ;;
            *)
                log "ERROR" "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    # Header
    echo -e "${BLUE}================================${NC}"
    echo -e "${BLUE}  AWS Cost Saver - EBS Cleanup${NC}"
    echo -e "${BLUE}================================${NC}"
    echo
    
    # Check prerequisites
    check_aws_cli
    
    # Load configuration
    load_config
    
    # Get AWS region
    if [[ -z "${AWS_REGION:-}" ]]; then
        AWS_REGION=$(get_aws_region)
    fi
    
    log "INFO" "Starting EBS cleanup process"
    log "INFO" "Region: $AWS_REGION"
    log "INFO" "Max unattached days: $MAX_UNATTACHED_DAYS"
    log "INFO" "Dry run: $DRY_RUN"
    log "INFO" "Log file: $LOG_FILE"
    
    # Execute cleanup
    get_unattached_volumes "$AWS_REGION"
    
    log "INFO" "EBS cleanup process completed"
}

# Trap to handle script interruption
trap 'log "WARN" "Script interrupted by user"; exit 1' INT TERM

# Run main function
main "$@"
