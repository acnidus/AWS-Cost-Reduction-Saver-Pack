#!/usr/bin/env python3
"""
AWS Cost Saver - RDS Optimization
Automatically stops non-production RDS instances during off-hours to save costs.

Author: AWS Cost Saver Pack
Version: 1.0.0
Tool created by: acnid.al@gmail.com
Support the project: https://buymeacoffee.com/acnidal
"""

import boto3
import yaml
import logging
import argparse
import sys
from datetime import datetime, timedelta
import pytz
from botocore.exceptions import ClientError, NoCredentialsError
import json
import os

class RDSOptimizationManager:
    def __init__(self, config_path='../config/config.yaml'):
        """Initialize the RDSOptimizationManager with configuration."""
        self.config = self.load_config(config_path)
        self.setup_logging()
        self.rds_client = None
        self.setup_aws_clients()
        
    def load_config(self, config_path):
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            print(f"Configuration file not found: {config_path}")
            sys.exit(1)
        except yaml.YAMLError as e:
            print(f"Error parsing configuration file: {e}")
            sys.exit(1)
    
    def setup_logging(self):
        """Setup logging configuration."""
        log_dir = '../logs'
        os.makedirs(log_dir, exist_ok=True)
        
        log_file = f"{log_dir}/optimize_rds_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        
        logging.basicConfig(
            level=getattr(logging, self.config.get('logging', {}).get('level', 'INFO')),
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info("RDS Optimization Manager initialized")
    
    def setup_aws_clients(self):
        """Setup AWS clients."""
        try:
            session = boto3.Session(
                region_name=self.config['aws']['region'],
                profile_name=self.config['aws']['profile']
            )
            self.rds_client = session.client('rds')
            self.logger.info(f"AWS RDS client initialized for region: {self.config['aws']['region']}")
        except NoCredentialsError:
            self.logger.error("AWS credentials not found. Please run 'aws configure'")
            sys.exit(1)
        except Exception as e:
            self.logger.error(f"Error setting up AWS clients: {e}")
            sys.exit(1)
    
    def get_rds_instances(self):
        """Get all RDS instances."""
        try:
            response = self.rds_client.describe_db_instances()
            instances = response['DBInstances']
            self.logger.info(f"Found {len(instances)} RDS instances")
            return instances
            
        except ClientError as e:
            self.logger.error(f"Error getting RDS instances: {e}")
            return []
    
    def should_exclude_instance(self, instance):
        """Check if RDS instance should be excluded from stopping."""
        rds_config = self.config.get('rds', {})
        production_tags = rds_config.get('production_tags', [])
        
        # Check instance state
        if instance['DBInstanceStatus'] not in ['available', 'stopped']:
            return True
        
        # Check for production tags
        if 'TagList' in instance:
            instance_tags = {tag['Key']: tag['Value'] for tag in instance['TagList']}
            
            for production_tag in production_tags:
                key, value = production_tag.split('=')
                if instance_tags.get(key) == value:
                    self.logger.info(f"Instance {instance['DBInstanceIdentifier']} excluded due to tag: {production_tag}")
                    return True
        
        # Check instance name for production indicators
        instance_name = instance['DBInstanceIdentifier'].lower()
        if any(keyword in instance_name for keyword in ['prod', 'production', 'live', 'critical']):
            self.logger.info(f"Instance {instance['DBInstanceIdentifier']} excluded due to name")
            return True
        
        # Check engine type (exclude Aurora clusters)
        if instance['Engine'] == 'aurora':
            self.logger.info(f"Instance {instance['DBInstanceIdentifier']} excluded - Aurora cluster")
            return True
        
        return False
    
    def is_off_hours(self):
        """Check if current time is within off-hours window."""
        rds_config = self.config.get('rds', {})
        stop_hours = rds_config.get('stop_hours', {})
        timezone_str = rds_config.get('timezone', 'UTC')
        
        try:
            # Parse time window
            start_time_str = stop_hours.get('start', '18:00')
            end_time_str = stop_hours.get('end', '08:00')
            
            # Convert to datetime objects
            start_time = datetime.strptime(start_time_str, '%H:%M').time()
            end_time = datetime.strptime(end_time_str, '%H:%M').time()
            
            # Get current time in specified timezone
            tz = pytz.timezone(timezone_str)
            current_time = datetime.now(tz).time()
            
            # Check if current time is within off-hours window
            if start_time > end_time:  # Overnight window (e.g., 18:00 to 08:00)
                return current_time >= start_time or current_time <= end_time
            else:  # Same-day window
                return start_time <= current_time <= end_time
                
        except Exception as e:
            self.logger.warning(f"Error checking off-hours: {e}, defaulting to True")
            return True
    
    def should_stop_instance(self, instance):
        """Determine if an instance should be stopped."""
        # Check if it's off-hours
        if not self.is_off_hours():
            return False
        
        # Check if instance is already stopped
        if instance['DBInstanceStatus'] == 'stopped':
            return False
        
        # Check if instance should be excluded
        if self.should_exclude_instance(instance):
            return False
        
        return True
    
    def stop_instance(self, instance_id, reason):
        """Stop an RDS instance."""
        try:
            if not self.config.get('rds', {}).get('dry_run', False):
                response = self.rds_client.stop_db_instance(DBInstanceIdentifier=instance_id)
                self.logger.info(f"Stopped RDS instance {instance_id}: {reason}")
                return True
            else:
                self.logger.info(f"[DRY RUN] Would stop RDS instance {instance_id}: {reason}")
                return True
                
        except ClientError as e:
            self.logger.error(f"Error stopping RDS instance {instance_id}: {e}")
            return False
    
    def start_instance(self, instance_id, reason):
        """Start an RDS instance."""
        try:
            if not self.config.get('rds', {}).get('dry_run', False):
                response = self.rds_client.start_db_instance(DBInstanceIdentifier=instance_id)
                self.logger.info(f"Started RDS instance {instance_id}: {reason}")
                return True
            else:
                self.logger.info(f"[DRY RUN] Would start RDS instance {instance_id}: {reason}")
                return True
                
        except ClientError as e:
            self.logger.error(f"Error starting RDS instance {instance_id}: {e}")
            return False
    
    def estimate_savings(self, instances):
        """Estimate cost savings from stopping instances."""
        total_savings = 0
        
        for instance in instances:
            instance_class = instance['DBInstanceClass']
            
            # Rough cost estimation (you might want to use AWS Pricing API for accuracy)
            cost_map = {
                'db.t3.micro': 0.017,
                'db.t3.small': 0.034,
                'db.t3.medium': 0.068,
                'db.t3.large': 0.136,
                'db.r5.large': 0.29,
                'db.r5.xlarge': 0.58,
                'db.m5.large': 0.171,
                'db.m5.xlarge': 0.342,
            }
            
            hourly_cost = cost_map.get(instance_class, 0.20)  # Default to $0.20/hour
            daily_savings = hourly_cost * 14  # Assume 14 hours stopped per day
            total_savings += daily_savings
        
        return total_savings
    
    def run(self, action='auto'):
        """Main execution method."""
        self.logger.info("Starting RDS optimization process")
        
        # Get configuration
        dry_run = self.config.get('rds', {}).get('dry_run', False)
        
        self.logger.info(f"Action: {action}")
        self.logger.info(f"Dry run mode: {dry_run}")
        self.logger.info(f"Current time: {datetime.now()}")
        self.logger.info(f"Off-hours check: {self.is_off_hours()}")
        
        # Get RDS instances
        instances = self.get_rds_instances()
        
        if not instances:
            self.logger.info("No RDS instances found")
            return
        
        instances_to_stop = []
        instances_to_start = []
        
        for instance in instances:
            instance_id = instance['DBInstanceIdentifier']
            status = instance['DBInstanceStatus']
            
            if action == 'stop' or action == 'auto':
                if self.should_stop_instance(instance):
                    instances_to_stop.append(instance)
            
            elif action == 'start':
                if status == 'stopped' and not self.should_exclude_instance(instance):
                    instances_to_start.append(instance)
        
        # Execute actions
        if action in ['stop', 'auto'] and instances_to_stop:
            self.logger.info(f"Found {len(instances_to_stop)} instances to stop")
            
            stopped_count = 0
            for instance in instances_to_stop:
                instance_id = instance['DBInstanceIdentifier']
                reason = f"Off-hours optimization - {instance['DBInstanceClass']}"
                
                if self.stop_instance(instance_id, reason):
                    stopped_count += 1
                
                # Small delay to avoid API throttling
                import time
                time.sleep(1)
            
            self.logger.info(f"Stopped {stopped_count} instances")
            
            # Estimate savings
            if stopped_count > 0:
                savings = self.estimate_savings(instances_to_stop)
                self.logger.info(f"Estimated daily savings: ${savings:.2f}")
        
        elif action == 'start' and instances_to_start:
            self.logger.info(f"Found {len(instances_to_start)} instances to start")
            
            started_count = 0
            for instance in instances_to_start:
                instance_id = instance['DBInstanceIdentifier']
                reason = "Business hours - starting instance"
                
                if self.start_instance(instance_id, reason):
                    started_count += 1
                
                # Small delay to avoid API throttling
                import time
                time.sleep(1)
            
            self.logger.info(f"Started {started_count} instances")
        
        else:
            self.logger.info("No actions required")
        
        # Save execution summary
        self.save_execution_summary(action, instances_to_stop, instances_to_start)
    
    def save_execution_summary(self, action, instances_to_stop, instances_to_start):
        """Save execution summary to a JSON file."""
        summary = {
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'instances_to_stop': len(instances_to_stop),
            'instances_to_start': len(instances_to_start),
            'off_hours': self.is_off_hours(),
            'config_used': {
                'stop_hours': self.config.get('rds', {}).get('stop_hours', {}),
                'timezone': self.config.get('rds', {}).get('timezone', 'UTC'),
                'dry_run': self.config.get('rds', {}).get('dry_run', False)
            }
        }
        
        log_dir = '../logs'
        summary_file = f"{log_dir}/rds_optimization_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(summary_file, 'w') as f:
                json.dump(summary, f, indent=2)
            self.logger.info(f"Execution summary saved to: {summary_file}")
        except Exception as e:
            self.logger.error(f"Error saving execution summary: {e}")

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='Optimize RDS instances by stopping/starting based on schedule')
    parser.add_argument('--config', '-c', default='../config/config.yaml',
                       help='Path to configuration file')
    parser.add_argument('--action', '-a', choices=['auto', 'stop', 'start'], default='auto',
                       help='Action to perform: auto (default), stop, or start')
    parser.add_argument('--dry-run', action='store_true',
                       help='Run in dry-run mode (no actual changes)')
    
    args = parser.parse_args()
    
    try:
        manager = RDSOptimizationManager(args.config)
        
        # Override configuration if specified via command line
        if args.dry_run:
            manager.config['rds']['dry_run'] = True
            manager.logger.info("Running in DRY-RUN mode")
        
        manager.run(args.action)
        
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
