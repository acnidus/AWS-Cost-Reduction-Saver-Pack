#!/usr/bin/env python3
"""
AWS Cost Saver - Daily Cost Report
Generates and sends daily AWS cost reports via email.

Author: AWS Cost Saver Pack
Version: 1.0.0
Tool created by: acnid.al@gmail.com
Support the project: https://buymeacoffee.com/acnidal
"""

import boto3
import yaml
import logging
import argparse
import sys
import smtplib
import ssl
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from botocore.exceptions import ClientError, NoCredentialsError
import json
import os
from jinja2 import Template
import requests

class DailyCostReporter:
    def __init__(self, config_path='../config/config.yaml'):
        """Initialize the DailyCostReporter with configuration."""
        self.config = self.load_config(config_path)
        self.setup_logging()
        self.ce_client = None
        self.setup_aws_clients()
        
    def load_config(self, config_path):
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            print(f"Configuration file not found: {config_path}")
            sys.exit(1)
        except yaml.YAMLError as e:
            print(f"Error parsing configuration file: {e}")
            sys.exit(1)
    
    def setup_logging(self):
        """Setup logging configuration."""
        log_dir = '../logs'
        os.makedirs(log_dir, exist_ok=True)
        
        log_file = f"{log_dir}/daily_cost_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        
        logging.basicConfig(
            level=getattr(logging, self.config.get('logging', {}).get('level', 'INFO')),
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info("Daily Cost Reporter initialized")
    
    def setup_aws_clients(self):
        """Setup AWS clients."""
        try:
            session = boto3.Session(
                region_name=self.config['aws']['region'],
                profile_name=self.config['aws']['profile']
            )
            self.ce_client = session.client('ce')
            self.logger.info(f"AWS Cost Explorer client initialized for region: {self.config['aws']['region']}")
        except NoCredentialsError:
            self.logger.error("AWS credentials not found. Please run 'aws configure'")
            sys.exit(1)
        except Exception as e:
            self.logger.error(f"Error setting up AWS clients: {e}")
            sys.exit(1)
    
    def get_cost_data(self, start_date, end_date):
        """Get cost data from AWS Cost Explorer."""
        try:
            response = self.ce_client.get_cost_and_usage(
                TimePeriod={
                    'Start': start_date.strftime('%Y-%m-%d'),
                    'End': end_date.strftime('%Y-%m-%d')
                },
                Granularity='DAILY',
                Metrics=['UnblendedCost'],
                GroupBy=[
                    {'Type': 'DIMENSION', 'Key': 'SERVICE'},
                    {'Type': 'DIMENSION', 'Key': 'REGION'}
                ]
            )
            
            return response
            
        except ClientError as e:
            self.logger.error(f"Error getting cost data: {e}")
            return None
    
    def get_previous_period_cost(self, start_date, end_date):
        """Get cost data for the previous period for comparison."""
        period_duration = end_date - start_date
        prev_start = start_date - period_duration
        prev_end = start_date
        
        return self.get_cost_data(prev_start, prev_end)
    
    def parse_cost_data(self, cost_data):
        """Parse cost data into a structured format."""
        if not cost_data or 'ResultsByTime' not in cost_data:
            return None
        
        daily_costs = []
        service_costs = {}
        total_cost = 0
        
        for result in cost_data['ResultsByTime']:
            date = result['TimePeriod']['Start'][:10]
            cost = float(result['Total']['UnblendedCost']['Amount'])
            total_cost += cost
            
            daily_costs.append({
                'date': date,
                'cost': cost
            })
            
            # Aggregate by service
            for group in result['Groups']:
                service = group['Keys'][0]
                service_cost = float(group['Metrics']['UnblendedCost']['Amount'])
                
                if service not in service_costs:
                    service_costs[service] = 0
                service_costs[service] += service_cost
        
        # Calculate service percentages
        service_breakdown = []
        for service, cost in service_costs.items():
            percentage = (cost / total_cost * 100) if total_cost > 0 else 0
            service_breakdown.append({
                'name': service,
                'cost': round(cost, 2),
                'percentage': round(percentage, 1)
            })
        
        # Sort by cost (highest first)
        service_breakdown.sort(key=lambda x: x['cost'], reverse=True)
        
        return {
            'daily_costs': daily_costs,
            'service_breakdown': service_breakdown,
            'total_cost': round(total_cost, 2),
            'daily_average': round(total_cost / len(daily_costs), 2) if daily_costs else 0
        }
    
    def calculate_cost_change(self, current_data, previous_data):
        """Calculate the percentage change in costs."""
        if not current_data or not previous_data:
            return 0
        
        current_total = current_data['total_cost']
        previous_total = previous_data['total_cost']
        
        if previous_total == 0:
            return 100 if current_total > 0 else 0
        
        change = ((current_total - previous_total) / previous_total) * 100
        return round(change, 1)
    
    def get_cost_optimization_recommendations(self, cost_data):
        """Generate cost optimization recommendations."""
        recommendations = []
        
        if not cost_data:
            return recommendations
        
        # Check for high-cost services
        for service in cost_data['service_breakdown'][:5]:  # Top 5 services
            if service['percentage'] > 20:  # If service is more than 20% of total cost
                recommendations.append({
                    'description': f"Review {service['name']} usage - it represents {service['percentage']}% of total costs",
                    'savings': round(service['cost'] * 0.1, 2)  # Assume 10% potential savings
                })
        
        # Check for cost trends
        if cost_data['daily_average'] > 100:  # If daily average is over $100
            recommendations.append({
                'description': "Daily costs are high - consider implementing cost controls and resource scheduling",
                'savings': round(cost_data['daily_average'] * 0.2, 2)  # Assume 20% potential savings
            })
        
        # Add general recommendations
        recommendations.extend([
            {
                'description': "Use Reserved Instances for predictable workloads",
                'savings': 30.0
            },
            {
                'description': "Implement auto-scaling to optimize resource utilization",
                'savings': 25.0
            },
            {
                'description': "Review and delete unused EBS volumes and snapshots",
                'savings': 15.0
            }
        ])
        
        return recommendations
    
    def check_cost_alerts(self, cost_data):
        """Check for cost alerts based on thresholds."""
        alerts = []
        cost_config = self.config.get('cost', {})
        alert_threshold = cost_config.get('alert_threshold_usd', 100)
        
        if cost_data and cost_data['total_cost'] > alert_threshold:
            alerts.append({
                'level': 'WARNING',
                'message': f"Daily costs (${cost_data['total_cost']}) exceed threshold (${alert_threshold})"
            })
        
        # Check for unusual cost spikes
        if cost_data and cost_data['daily_costs']:
            costs = [day['cost'] for day in cost_data['daily_costs']]
            avg_cost = sum(costs) / len(costs)
            max_cost = max(costs)
            
            if max_cost > avg_cost * 2:  # If any day is more than 2x the average
                alerts.append({
                    'level': 'ALERT',
                    'message': f"Unusual cost spike detected: ${max_cost} (average: ${avg_cost:.2f})"
                })
        
        return alerts
    
    def load_email_template(self):
        """Load the HTML email template."""
        template_path = '../config/email_template.html'
        try:
            with open(template_path, 'r') as file:
                return file.read()
        except FileNotFoundError:
            self.logger.warning(f"Email template not found: {template_path}")
            return self.get_default_template()
    
    def get_default_template(self):
        """Get a default email template if the custom one is not found."""
        return """
        <html>
        <body>
            <h1>AWS Cost Report</h1>
            <p>Generated on {{ generation_date }}</p>
            {% if cost_summary %}
            <h2>Cost Summary</h2>
            <p>Total Cost: ${{ total_cost }}</p>
            <p>Daily Average: ${{ daily_average }}</p>
            {% endif %}
        </body>
        </html>
        """
    
    def generate_email_content(self, cost_data, previous_data, recommendations, alerts):
        """Generate email content using the template."""
        template_content = self.load_email_template()
        template = Template(template_content)
        
        # Calculate cost change
        cost_change = self.calculate_cost_change(cost_data, previous_data)
        
        # Prepare template variables
        template_vars = {
            'generation_date': datetime.now().strftime('%Y-%m-%d'),
            'generation_time': datetime.now().strftime('%H:%M:%S UTC'),
            'cost_summary': cost_data is not None,
            'total_cost': cost_data['total_cost'] if cost_data else 0,
            'daily_average': cost_data['daily_average'] if cost_data else 0,
            'period': 'Last 7 days',
            'cost_change': cost_change,
            'cost_breakdown': cost_data['service_breakdown'] if cost_data else [],
            'recommendations': recommendations,
            'alerts': alerts,
            'aws_console_url': f"https://console.aws.amazon.com/",
            'cost_explorer_url': f"https://console.aws.amazon.com/cost-explorer/",
            'billing_url': f"https://console.aws.amazon.com/billing/"
        }
        
        # Add actions taken if available
        actions_file = f"../logs/execution_summary_{datetime.now().strftime('%Y%m%d')}.json"
        actions_taken = []
        total_resources = 0
        estimated_savings = 0
        
        try:
            if os.path.exists(actions_file):
                with open(actions_file, 'r') as f:
                    summary = json.load(f)
                    if 'stopped_instances' in summary and summary['stopped_instances'] > 0:
                        actions_taken.append({
                            'type': 'EC2 Instances',
                            'description': f"Stopped {summary['stopped_instances']} idle instances"
                        })
                        total_resources += summary['stopped_instances']
                        estimated_savings += summary.get('estimated_daily_savings', 0)
        except Exception as e:
            self.logger.warning(f"Could not load actions summary: {e}")
        
        template_vars.update({
            'actions_taken': actions_taken,
            'total_resources': total_resources,
            'estimated_savings': round(estimated_savings, 2)
        })
        
        return template.render(**template_vars)
    
    def send_email(self, subject, html_content):
        """Send email using configured SMTP settings."""
        email_config = self.config.get('email', {})
        
        if not email_config.get('username') or email_config.get('username') == 'your-email@gmail.com':
            self.logger.warning("Email not configured, skipping email send")
            return False
        
        try:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = email_config['from_address']
            msg['To'] = ', '.join(self.config['cost']['alert_recipients'])
            
            # Attach HTML content
            html_part = MIMEText(html_content, 'html')
            msg.attach(html_part)
            
            # Create SMTP connection
            context = ssl.create_default_context()
            
            with smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port']) as server:
                if email_config['use_tls']:
                    server.starttls(context=context)
                
                server.login(email_config['username'], email_config['password'])
                server.send_message(msg)
            
            self.logger.info("Email sent successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Error sending email: {e}")
            return False
    
    def save_report(self, cost_data, recommendations, alerts):
        """Save the cost report to a JSON file."""
        report_data = {
            'timestamp': datetime.now().isoformat(),
            'cost_data': cost_data,
            'recommendations': recommendations,
            'alerts': alerts,
            'config_used': {
                'region': self.config['aws']['region'],
                'alert_threshold': self.config['cost']['alert_threshold_usd']
            }
        }
        
        log_dir = '../logs'
        report_file = f"{log_dir}/cost_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(report_file, 'w') as f:
                json.dump(report_data, f, indent=2)
            self.logger.info(f"Cost report saved to: {report_file}")
        except Exception as e:
            self.logger.error(f"Error saving cost report: {e}")
    
    def run(self):
        """Main execution method."""
        self.logger.info("Starting daily cost report generation")
        
        # Calculate date range (last 7 days)
        end_date = datetime.now()
        start_date = end_date - timedelta(days=7)
        
        self.logger.info(f"Generating cost report for period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
        
        # Get current period cost data
        cost_data = self.get_cost_data(start_date, end_date)
        if not cost_data:
            self.logger.error("Failed to retrieve cost data")
            return
        
        # Parse cost data
        parsed_cost_data = self.parse_cost_data(cost_data)
        if not parsed_cost_data:
            self.logger.error("Failed to parse cost data")
            return
        
        # Get previous period data for comparison
        previous_data = self.get_previous_period_cost(start_date, end_date)
        parsed_previous_data = self.parse_cost_data(previous_data) if previous_data else None
        
        # Generate recommendations
        recommendations = self.get_cost_optimization_recommendations(parsed_cost_data)
        
        # Check for alerts
        alerts = self.check_cost_alerts(parsed_cost_data)
        
        # Generate email content
        html_content = self.generate_email_content(
            parsed_cost_data, 
            parsed_previous_data, 
            recommendations, 
            alerts
        )
        
        # Save report
        self.save_report(parsed_cost_data, recommendations, alerts)
        
        # Send email if configured
        subject = f"AWS Cost Report - {datetime.now().strftime('%Y-%m-%d')}"
        if self.send_email(subject, html_content):
            self.logger.info("Daily cost report completed successfully")
        else:
            self.logger.warning("Daily cost report generated but email not sent")
        
        # Print summary to console
        self.print_summary(parsed_cost_data, recommendations, alerts)
    
    def print_summary(self, cost_data, recommendations, alerts):
        """Print a summary to the console."""
        print("\n" + "="*60)
        print("AWS COST REPORT SUMMARY")
        print("="*60)
        
        if cost_data:
            print(f"Total Cost (7 days): ${cost_data['total_cost']}")
            print(f"Daily Average: ${cost_data['daily_average']}")
            print(f"Top Services:")
            for service in cost_data['service_breakdown'][:3]:
                print(f"  - {service['name']}: ${service['cost']} ({service['percentage']}%)")
        
        if recommendations:
            print(f"\nRecommendations ({len(recommendations)}):")
            for rec in recommendations[:3]:
                print(f"  - {rec['description']}")
        
        if alerts:
            print(f"\nAlerts ({len(alerts)}):")
            for alert in alerts:
                print(f"  - {alert['level']}: {alert['message']}")
        
        print("="*60)

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='Generate and send daily AWS cost reports')
    parser.add_argument('--config', '-c', default='../config/config.yaml',
                       help='Path to configuration file')
    parser.add_argument('--no-email', action='store_true',
                       help='Generate report without sending email')
    
    args = parser.parse_args()
    
    try:
        reporter = DailyCostReporter(args.config)
        
        if args.no_email:
            reporter.config['email']['username'] = None
            reporter.logger.info("Running in no-email mode")
        
        reporter.run()
        
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
