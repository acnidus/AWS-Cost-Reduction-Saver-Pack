# AWS Cost Saver Pack - Setup Guide

This guide provides step-by-step instructions for setting up and configuring the AWS Cost Saver Pack.

**Tool created by:** [acnid.al@gmail.com](mailto:acnid.al@gmail.com)  
**Support the project:** [Buy Me a Coffee ☕](https://buymeacoffee.com/acnidal)

## 📋 Prerequisites

### System Requirements
- **Operating System**: Linux, macOS, or Windows (with WSL)
- **Python**: 3.7 or higher
- **Memory**: Minimum 512MB RAM
- **Storage**: At least 100MB free space

### Required Software
- **Python 3.7+**: [Download from python.org](https://www.python.org/downloads/)
- **AWS CLI**: [Installation guide](https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html)
- **Git**: For cloning the repository

### AWS Account Requirements
- Active AWS account with billing enabled
- IAM user with appropriate permissions (see [Permissions](#aws-permissions))
- Cost Explorer access enabled

## 🚀 Installation Steps

### Step 1: Clone or Download the Package
```bash
# Option 1: Clone from Git (if available)
git clone <repository-url>
cd AWS_Cost_Saver_Pack

# Option 2: Download and extract ZIP file
wget <download-url>
unzip AWS_Cost_Saver_Pack.zip
cd AWS_Cost_Saver_Pack
```

### Step 2: Install Python Dependencies
```bash
# Create virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install required packages
pip install -r requirements.txt

# Verify installation
python3 -c "import boto3, yaml, jinja2; print('Dependencies installed successfully')"
```

### Step 3: Configure AWS Credentials
```bash
# Configure AWS CLI with your credentials
aws configure

# Enter your:
# - AWS Access Key ID
# - AWS Secret Access Key
# - Default region (e.g., us-east-1)
# - Default output format (json)

# Verify configuration
aws sts get-caller-identity
```

### Step 4: Configure the Package
```bash
# Copy and edit the configuration file
cp config/config.yaml config/config.yaml.backup
nano config/config.yaml  # or use your preferred editor
```

## ⚙️ Configuration

### Basic Configuration
Edit `config/config.yaml` with your settings:

```yaml
aws:
  region: us-east-1          # Your AWS region
  profile: default           # AWS profile to use

ec2:
  idle_threshold_hours: 24   # Hours before considering instance idle
  cpu_threshold_percent: 5   # CPU threshold for idle detection
  dry_run: true             # Start with dry-run for safety

email:
  smtp_server: smtp.gmail.com
  username: your-email@gmail.com
  password: your-app-password
```

### Email Configuration
For Gmail, you'll need to:
1. Enable 2-factor authentication
2. Generate an App Password
3. Use the App Password in the config file

### Cost Thresholds
```yaml
cost:
  alert_threshold_usd: 100      # Daily cost alert threshold
  monthly_alert_threshold_usd: 1000  # Monthly cost alert threshold
  alert_recipients:
    - "admin@company.com"
    - "finance@company.com"
```

## 🔐 AWS Permissions

### Required IAM Policy
Create an IAM user with the following policy:

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ec2:DescribeInstances",
                "ec2:DescribeVolumes",
                "ec2:DescribeSnapshots",
                "ec2:StopInstances",
                "ec2:DeleteVolume",
                "ec2:DeleteSnapshot",
                "ce:GetCostAndUsage",
                "rds:DescribeDBInstances",
                "rds:StopDBInstance",
                "rds:StartDBInstance",
                "logs:DescribeLogGroups",
                "logs:DeleteLogGroup"
            ],
            "Resource": "*"
        }
    ]
}
```

### Creating IAM User
1. Go to AWS IAM Console
2. Create a new user
3. Attach the policy above
4. Generate access keys
5. Use these keys with `aws configure`

## 🧪 Testing the Setup

### Test Individual Scripts
```bash
# Test idle instance detection (dry-run)
python3 scripts/stop_idle_instances.py --dry-run

# Test EBS cleanup (dry-run)
bash scripts/clean_unused_ebs.sh --dry-run

# Test cost reporting (no email)
python3 scripts/daily_cost_report.py --no-email

# Test RDS optimization (dry-run)
python3 scripts/optimize_rds.py --dry-run
```

### Verify Logs
Check the `logs/` directory for execution logs:
```bash
ls -la logs/
tail -f logs/stop_idle_instances_*.log
```

## 🔧 Advanced Configuration

### Custom Tags for Resource Protection
```yaml
ec2:
  excluded_tags:
    - "Environment=Production"
    - "AutoStop=false"
    - "Critical=true"
    - "Backup=Required"
```

### Multiple AWS Profiles
```yaml
aws:
  region: us-east-1
  profile: production  # Use specific AWS profile
```

### Custom Time Windows
```yaml
rds:
  stop_hours:
    start: "18:00"    # 6 PM
    end: "08:00"      # 8 AM
  timezone: "America/New_York"
```

## 📊 Monitoring Setup

### CloudWatch Integration
Enable CloudWatch metrics for EC2 instances:
1. Go to EC2 Console
2. Select instances
3. Actions → Monitor and troubleshoot → Manage CloudWatch monitoring
4. Enable detailed monitoring

### Cost Explorer Setup
1. Go to AWS Cost Explorer
2. Ensure billing data is available
3. Wait 24-48 hours for data to populate

## 🚨 Safety Features

### Dry-Run Mode
Always start with dry-run mode:
```bash
python3 scripts/stop_idle_instances.py --dry-run
```

### Resource Tagging
Tag critical resources to prevent accidental modification:
```bash
# Tag production instances
aws ec2 create-tags --resources i-1234567890abcdef0 --tags Key=Environment,Value=Production
```

### Backup Strategy
Before running cleanup scripts:
1. Create EBS snapshots of important volumes
2. Document current resource state
3. Test in non-production environment first

## 🔄 Automation Setup

### Cron Jobs
Set up automated execution:
```bash
# Edit crontab
crontab -e

# Add daily execution
0 2 * * * /usr/bin/python3 /path/to/scripts/stop_idle_instances.py
0 3 * * * /bin/bash /path/to/scripts/clean_unused_ebs.sh
0 8 * * * /usr/bin/python3 /path/to/scripts/daily_cost_report.py
```

### Systemd Service (Linux)
Create a systemd service for continuous monitoring:
```bash
sudo nano /etc/systemd/system/aws-cost-saver.service
```

## 🆘 Troubleshooting

### Common Issues

#### AWS Credentials Error
```bash
# Check credentials
aws sts get-caller-identity

# Reconfigure if needed
aws configure
```

#### Permission Denied
```bash
# Check IAM permissions
aws iam get-user
aws iam list-attached-user-policies --user-name <username>
```

#### Python Import Errors
```bash
# Check Python path
which python3
python3 -c "import sys; print(sys.path)"

# Reinstall dependencies
pip install --force-reinstall -r requirements.txt
```

#### Script Execution Errors
```bash
# Check file permissions
chmod +x scripts/*.py
chmod +x scripts/*.sh

# Check Python shebang
head -1 scripts/stop_idle_instances.py
```

### Getting Help
1. Check the logs in `logs/` directory
2. Review the troubleshooting guide
3. Check AWS CloudTrail for API errors
4. Verify configuration file syntax

## ✅ Verification Checklist

- [ ] Python 3.7+ installed and accessible
- [ ] AWS CLI configured and working
- [ ] Required Python packages installed
- [ ] Configuration file edited and saved
- [ ] AWS permissions verified
- [ ] Test scripts run successfully (dry-run)
- [ ] Logs generated in logs/ directory
- [ ] Email configuration tested (if using)
- [ ] Cron jobs configured (if automating)
- [ ] Resource tagging strategy implemented

## 🔗 Next Steps

After successful setup:
1. Review the [Configuration Guide](CONFIGURATION.md)
2. Set up automated execution
3. Monitor logs and adjust thresholds
4. Implement resource tagging strategy
5. Set up cost monitoring and alerts

## 📞 Support

For additional help:
- Check the troubleshooting section
- Review AWS documentation
- Ensure all prerequisites are met
- Test in a non-production environment first
