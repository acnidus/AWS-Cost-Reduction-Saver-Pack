# AWS Cost Saver Pack - Troubleshooting Guide

This guide helps you resolve common issues and problems that may occur when using the AWS Cost Saver Pack.

**Tool created by:** [acnid.al@gmail.com](mailto:acnid.al@gmail.com)  
**Support the project:** [Buy Me a Coffee ☕](https://buymeacoffee.com/acnidal)

## 🚨 Emergency Stop

If you need to immediately stop all automated processes:

```bash
# Stop all cron jobs
crontab -r

# Kill any running Python processes
pkill -f "aws-cost-saver"

# Check for running processes
ps aux | grep -E "(stop_idle|clean_unused|daily_cost|optimize_rds)"
```

## 🔍 Common Issues and Solutions

### 1. AWS Credentials and Permissions

#### Issue: "AWS credentials not found"
```
Error: AWS credentials not found. Please run 'aws configure' first.
```

**Solutions:**
```bash
# Check if AWS CLI is configured
aws sts get-caller-identity

# If not configured, run:
aws configure

# Verify credentials work
aws ec2 describe-regions

# Check environment variables
echo $AWS_ACCESS_KEY_ID
echo $AWS_SECRET_ACCESS_KEY
echo $AWS_DEFAULT_REGION
```

#### Issue: "Access Denied" or "Unauthorized"
```
Error: An error occurred (UnauthorizedOperation) when calling the DescribeInstances operation
```

**Solutions:**
1. **Check IAM permissions:**
```bash
# Verify your IAM user
aws iam get-user

# Check attached policies
aws iam list-attached-user-policies --user-name <your-username>

# Check inline policies
aws iam list-user-policies --user-name <your-username>
```

2. **Required IAM permissions:**
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ec2:DescribeInstances",
                "ec2:DescribeVolumes",
                "ec2:DescribeSnapshots",
                "ec2:StopInstances",
                "ec2:DeleteVolume",
                "ec2:DeleteSnapshot",
                "ce:GetCostAndUsage",
                "rds:DescribeDBInstances",
                "rds:StopDBInstance",
                "rds:StartDBInstance"
            ],
            "Resource": "*"
        }
    ]
}
```

3. **Check if you're in the right account:**
```bash
# Verify account ID
aws sts get-caller-identity --query 'Account' --output text

# Check if you have access to the region
aws ec2 describe-regions --region-names us-east-1
```

### 2. Python and Dependencies

#### Issue: "ModuleNotFoundError: No module named 'boto3'"
```
Error: ModuleNotFoundError: No module named 'boto3'
```

**Solutions:**
```bash
# Check Python version
python3 --version

# Check if virtual environment is activated
echo $VIRTUAL_ENV

# Install dependencies
pip install -r requirements.txt

# Or install individually
pip install boto3 botocore PyYAML jinja2

# Check installed packages
pip list | grep -E "(boto3|botocore|PyYAML|jinja2)"
```

#### Issue: "ImportError: cannot import name 'yaml'"
```
Error: ImportError: cannot import name 'yaml'
```

**Solutions:**
```bash
# Uninstall and reinstall PyYAML
pip uninstall PyYAML
pip install PyYAML

# Check for conflicts
pip check

# Try alternative installation
pip install --force-reinstall PyYAML
```

### 3. Configuration File Issues

#### Issue: "Configuration file not found"
```
Error: Configuration file not found: ../config/config.yaml
```

**Solutions:**
```bash
# Check current directory
pwd

# Check if config file exists
ls -la config/

# Check file permissions
ls -la config/config.yaml

# Fix path if running from wrong directory
cd /path/to/AWS_Cost_Saver_Pack
python3 scripts/stop_idle_instances.py
```

#### Issue: "Error parsing configuration file"
```
Error: Error parsing configuration file: <yaml error details>
```

**Solutions:**
1. **Validate YAML syntax:**
```bash
# Check YAML syntax
python3 -c "
import yaml
with open('config/config.yaml', 'r') as f:
    yaml.safe_load(f)
print('YAML is valid')
"
```

2. **Common YAML issues:**
```yaml
# ❌ Wrong - missing quotes around special characters
email:
  username: admin@company.com  # @ can cause issues

# ✅ Correct - use quotes
email:
  username: "admin@company.com"

# ❌ Wrong - inconsistent indentation
ec2:
idle_threshold_hours: 24

# ✅ Correct - consistent indentation
ec2:
  idle_threshold_hours: 24
```

3. **Use online YAML validator:**
   - [YAML Validator](https://www.yamllint.com/)
   - [YAML Lint](http://www.yamllint.com/)

### 4. Script Execution Issues

#### Issue: "Permission denied" when running scripts
```
Error: bash: ./scripts/clean_unused_ebs.sh: Permission denied
```

**Solutions:**
```bash
# Make scripts executable
chmod +x scripts/*.py
chmod +x scripts/*.sh

# Check permissions
ls -la scripts/

# Run with explicit interpreter
python3 scripts/stop_idle_instances.py
bash scripts/clean_unused_ebs.sh
```

#### Issue: "Script interrupted by user"
```
Error: Script interrupted by user
```

**Solutions:**
1. **Check if script is still running:**
```bash
ps aux | grep -E "(stop_idle|clean_unused|daily_cost)"
```

2. **Check for stuck processes:**
```bash
# Kill stuck processes
pkill -f "stop_idle_instances.py"

# Check AWS API calls
aws ec2 describe-instances --query 'Reservations[].Instances[?State.Name==`stopping`]'
```

### 5. AWS API and Rate Limiting

#### Issue: "Rate exceeded" or "ThrottlingException"
```
Error: An error occurred (ThrottlingException) when calling the DescribeInstances operation
```

**Solutions:**
1. **Add delays between API calls:**
```python
import time
time.sleep(1)  # Wait 1 second between calls
```

2. **Implement exponential backoff:**
```python
import time
import random

def api_call_with_retry(func, *args, **kwargs):
    max_retries = 5
    for attempt in range(max_retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if "ThrottlingException" in str(e) and attempt < max_retries - 1:
                wait_time = (2 ** attempt) + random.uniform(0, 1)
                time.sleep(wait_time)
                continue
            raise
```

3. **Check AWS service quotas:**
```bash
# Check EC2 API limits
aws service-quotas get-service-quota --service-code ec2 --quota-code L-85EED4F4

# Check RDS API limits
aws service-quotas get-service-quota --service-code rds --quota-code L-7B6409CD
```

### 6. Email and Notification Issues

#### Issue: "Error sending email"
```
Error: Error sending email: [Errno 11001] getaddrinfo failed
```

**Solutions:**
1. **Check SMTP configuration:**
```yaml
email:
  smtp_server: "smtp.gmail.com"
  smtp_port: 587
  use_tls: true
  username: "your-email@gmail.com"
  password: "your-app-password"  # Not your regular password
```

2. **Test email configuration:**
```bash
# Test SMTP connection
python3 -c "
import smtplib
server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login('your-email@gmail.com', 'your-app-password')
print('SMTP connection successful')
server.quit()
"
```

3. **Gmail-specific issues:**
   - Enable 2-factor authentication
   - Generate App Password (not regular password)
   - Allow less secure apps (if not using App Password)

#### Issue: "Slack webhook failed"
```
Error: Failed to send Slack alert: 400
```

**Solutions:**
1. **Check webhook URL:**
```bash
# Test webhook
curl -X POST -H 'Content-type: application/json' \
  --data '{"text":"Test message"}' \
  https://hooks.slack.com/services/YOUR/WEBHOOK/URL
```

2. **Verify webhook permissions:**
   - Check if webhook is still active
   - Verify channel permissions
   - Check if webhook is rate-limited

### 7. Resource Management Issues

#### Issue: "No instances found" or "No volumes found"
```
Info: No running instances found
Info: No unattached volumes found
```

**Solutions:**
1. **Check if resources exist:**
```bash
# Check EC2 instances
aws ec2 describe-instances --query 'Reservations[].Instances[?State.Name==`running`]'

# Check EBS volumes
aws ec2 describe-volumes --filters "Name=status,Values=available"

# Check RDS instances
aws rds describe-db-instances --query 'DBInstances[?DBInstanceStatus==`available`]'
```

2. **Check region configuration:**
```bash
# Verify current region
aws configure get region

# List resources in specific region
aws ec2 describe-instances --region us-west-2
```

3. **Check resource tags:**
```bash
# Check instance tags
aws ec2 describe-instances --query 'Reservations[].Instances[].Tags'

# Check volume tags
aws ec2 describe-volumes --query 'Volumes[].Tags'
```

#### Issue: "Instance excluded due to tag"
```
Info: Instance i-1234567890abcdef0 excluded due to tag: Environment=Production
```

**Solutions:**
1. **Review exclusion tags in config:**
```yaml
ec2:
  excluded_tags:
    - "Environment=Production"
    - "AutoStop=false"
    - "Critical=true"
```

2. **Check actual instance tags:**
```bash
aws ec2 describe-tags --filters "Name=resource-id,Values=i-1234567890abcdef0"
```

3. **Modify exclusion logic if needed:**
```yaml
ec2:
  excluded_tags:
    - "Environment=Production"  # Only exclude production
    # Remove other exclusions if too restrictive
```

### 8. Cost and Billing Issues

#### Issue: "No cost data available"
```
Error: Failed to retrieve cost data
```

**Solutions:**
1. **Check Cost Explorer access:**
```bash
# Test Cost Explorer API
aws ce get-cost-and-usage \
  --time-period Start=2024-01-01,End=2024-01-02 \
  --granularity DAILY \
  --metrics UnblendedCost
```

2. **Verify billing data availability:**
   - Cost data takes 24-48 hours to appear
   - Ensure billing is enabled for your account
   - Check if you have access to Cost Explorer

3. **Check IAM permissions:**
```json
{
    "Effect": "Allow",
    "Action": [
        "ce:GetCostAndUsage",
        "ce:GetCostForecast",
        "ce:GetDimensionValues"
    ],
    "Resource": "*"
}
```

#### Issue: "Cost threshold exceeded but no alert sent"
```
Warning: Daily costs ($150) exceed threshold ($100) but no alert sent
```

**Solutions:**
1. **Check email configuration:**
```yaml
email:
  username: "your-email@gmail.com"  # Must be set
  password: "your-app-password"     # Must be set
```

2. **Check alert recipients:**
```yaml
cost:
  alert_recipients:
    - "admin@company.com"      # Must have at least one
    - "finance@company.com"
```

3. **Test email manually:**
```bash
python3 scripts/cost_alert.py --no-email
```

### 9. Performance and Resource Issues

#### Issue: "Script running very slowly"
```
Info: Processing 1000 instances, this may take a while...
```

**Solutions:**
1. **Optimize API calls:**
```python
# Use pagination for large datasets
paginator = ec2_client.get_paginator('describe_instances')
for page in paginator.paginate():
    # Process page
    pass
```

2. **Implement parallel processing:**
```python
import concurrent.futures

def process_instance(instance):
    # Process single instance
    pass

with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
    futures = [executor.submit(process_instance, inst) for inst in instances]
    for future in concurrent.futures.as_completed(futures):
        result = future.result()
```

3. **Add progress indicators:**
```python
from tqdm import tqdm

for instance in tqdm(instances, desc="Processing instances"):
    # Process instance
    pass
```

#### Issue: "High memory usage"
```
Error: MemoryError: Unable to allocate array
```

**Solutions:**
1. **Process resources in batches:**
```python
def process_in_batches(resources, batch_size=100):
    for i in range(0, len(resources), batch_size):
        batch = resources[i:i + batch_size]
        # Process batch
        yield batch
```

2. **Use generators for large datasets:**
```python
def get_instances_generator():
    paginator = ec2_client.get_paginator('describe_instances')
    for page in paginator.paginate():
        for reservation in page['Reservations']:
            for instance in reservation['Instances']:
                yield instance
```

### 10. Logging and Debugging Issues

#### Issue: "No logs generated"
```
Warning: Could not create log directory
```

**Solutions:**
1. **Check directory permissions:**
```bash
# Check if logs directory exists
ls -la logs/

# Create if missing
mkdir -p logs

# Check permissions
ls -la logs/
chmod 755 logs/
```

2. **Check log configuration:**
```yaml
logging:
  level: "INFO"              # Set to DEBUG for more detail
  max_log_files: 10
  max_log_size_mb: 10
```

3. **Enable debug logging:**
```bash
# Run with debug logging
python3 scripts/stop_idle_instances.py --config config/debug.yaml

# Or set environment variable
export LOG_LEVEL=DEBUG
python3 scripts/stop_idle_instances.py
```

#### Issue: "Log files too large"
```
Warning: Log file size exceeds 100MB
```

**Solutions:**
1. **Implement log rotation:**
```python
import logging.handlers

handler = logging.handlers.RotatingFileHandler(
    'logs/script.log',
    maxBytes=10*1024*1024,  # 10MB
    backupCount=5
)
```

2. **Clean up old logs:**
```bash
# Remove logs older than 30 days
find logs/ -name "*.log" -mtime +30 -delete

# Compress old logs
find logs/ -name "*.log" -mtime +7 -exec gzip {} \;
```

## 🔧 Advanced Troubleshooting

### Debug Mode
Enable debug mode for detailed information:

```bash
# Set debug environment variables
export DEBUG=true
export LOG_LEVEL=DEBUG
export AWS_SDK_LOAD_CONFIG=1

# Run script with debug output
python3 -u scripts/stop_idle_instances.py --dry-run
```

### AWS CLI Debug Mode
```bash
# Enable AWS CLI debug mode
export AWS_CLI_DEBUG=1

# Run AWS command to see detailed API calls
aws ec2 describe-instances --region us-east-1
```

### Python Debugger
```python
import pdb; pdb.set_trace()  # Add this line where you want to debug

# Or use ipdb for better debugging
import ipdb; ipdb.set_trace()
```

## 📞 Getting Help

### Self-Diagnosis Steps
1. **Check the logs:** `tail -f logs/script_name_*.log`
2. **Verify configuration:** `python3 -c "import yaml; yaml.safe_load(open('config/config.yaml'))"`
3. **Test AWS connectivity:** `aws sts get-caller-identity`
4. **Check script permissions:** `ls -la scripts/`
5. **Verify Python environment:** `python3 -c "import sys; print(sys.path)"`

### External Resources
- **AWS Documentation:** [docs.aws.amazon.com](https://docs.aws.amazon.com/)
- **Python Documentation:** [docs.python.org](https://docs.python.org/)
- **Boto3 Documentation:** [boto3.amazonaws.com](https://boto3.amazonaws.com/)

### Support Checklist
- [ ] Checked all logs for error messages
- [ ] Verified AWS credentials and permissions
- [ ] Tested configuration file syntax
- [ ] Confirmed Python dependencies are installed
- [ ] Verified resource existence in AWS
- [ ] Checked network connectivity
- [ ] Tested with dry-run mode first

## 🚀 Performance Optimization

### Common Optimizations
1. **Use pagination for large datasets**
2. **Implement parallel processing**
3. **Cache frequently accessed data**
4. **Use batch operations**
5. **Implement exponential backoff for API calls**

### Monitoring Performance
```bash
# Monitor script execution time
time python3 scripts/stop_idle_instances.py

# Check memory usage
/usr/bin/time -v python3 scripts/stop_idle_instances.py

# Monitor AWS API calls
aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventName,AttributeValue=DescribeInstances
```

Remember: Always test troubleshooting steps in a non-production environment first, and keep backups of your configuration files before making changes!
