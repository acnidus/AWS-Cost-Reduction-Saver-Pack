# AWS Cost Saver Pack - Configuration Guide

This guide provides detailed information about all configuration options available in the AWS Cost Saver Pack.

**Tool created by:** [acnid.al@gmail.com](mailto:acnid.al@gmail.com)  
**Support the project:** [Buy Me a Coffee ☕](https://buymeacoffee.com/acnidal)

## 📁 Configuration File Structure

The main configuration file is located at `config/config.yaml` and contains several sections:

```yaml
aws:           # AWS connection settings
ec2:           # EC2 instance management
ebs:           # EBS volume management
rds:           # RDS optimization
cost:          # Cost monitoring and alerts
email:         # Email notification settings
logging:       # Logging configuration
safety:        # Safety and confirmation settings
notifications: # Additional notification channels
schedule:      # Automated execution schedules
```

## 🔧 AWS Configuration

### Basic AWS Settings
```yaml
aws:
  region: us-east-1      # AWS region for operations
  profile: default       # AWS profile name
```

**Available Regions:**
- `us-east-1` (N. Virginia)
- `us-west-2` (Oregon)
- `eu-west-1` (Ireland)
- `ap-southeast-1` (Singapore)
- And many more...

**Profile Options:**
- `default` - Uses default AWS credentials
- `production` - Uses production profile
- `development` - Uses development profile

### Multiple AWS Accounts
```yaml
aws:
  region: us-east-1
  profile: production
  # You can also use environment variables:
  # AWS_PROFILE=production
  # AWS_DEFAULT_REGION=us-east-1
```

## 🖥️ EC2 Configuration

### Instance Management Settings
```yaml
ec2:
  idle_threshold_hours: 24        # Hours before considering instance idle
  cpu_threshold_percent: 5        # CPU utilization threshold (%)
  network_threshold_mb: 10        # Network activity threshold (MB)
  dry_run: false                  # Enable dry-run mode
  max_instances_per_run: 50       # Maximum instances to process per run
```

**Idle Detection Logic:**
- Instance must be running for `idle_threshold_hours`
- CPU utilization below `cpu_threshold_percent`
- Network activity below `network_threshold_mb`

### Resource Protection
```yaml
ec2:
  excluded_tags:
    - "Environment=Production"     # Never stop production instances
    - "AutoStop=false"            # Explicitly exclude from auto-stop
    - "Critical=true"             # Critical business instances
    - "Backup=Required"           # Instances with backup requirements
    - "Maintenance=Excluded"      # Exclude from maintenance
```

**Tag Format:**
- `Key=Value` format
- Multiple tags can be specified
- All conditions must be met to exclude an instance

### Advanced EC2 Settings
```yaml
ec2:
  # Instance type cost mapping (for savings estimation)
  cost_estimation:
    t3.micro: 0.0104
    t3.small: 0.0208
    t3.medium: 0.0416
    t3.large: 0.0832
  
  # CloudWatch metrics configuration
  cloudwatch:
    metrics_period: 3600          # Metrics collection period (seconds)
    metrics_hours_back: 24        # How far back to check metrics
```

## 💾 EBS Configuration

### Volume Management
```yaml
ebs:
  max_unattached_days: 7          # Days before deleting unattached volumes
  dry_run: false                  # Enable dry-run mode
  max_volumes_per_run: 100        # Maximum volumes to process per run
  backup_before_delete: true      # Create snapshot before deletion
```

### Volume Type Protection
```yaml
ebs:
  excluded_volume_types:
    - "gp3"                       # Never delete GP3 volumes
    - "io2"                       # Never delete IO2 volumes
    - "st1"                       # Never delete ST1 volumes
    - "sc1"                       # Never delete SC1 volumes
```

### Volume Tagging Strategy
```yaml
ebs:
  # Volumes with these tags will be protected
  protected_tags:
    - "Backup=Required"
    - "Critical=true"
    - "Environment=Production"
    - "Retention=LongTerm"
```

## 🗄️ RDS Configuration

### Database Optimization
```yaml
rds:
  stop_non_production: true       # Enable RDS optimization
  dry_run: false                  # Enable dry-run mode
  
  # Production protection tags
  production_tags:
    - "Environment=Production"
    - "Critical=true"
    - "BusinessHours=24x7"
    - "Maintenance=Excluded"
```

### Time-Based Scheduling
```yaml
rds:
  stop_hours:
    start: "18:00"                # Start stopping at 6 PM
    end: "08:00"                  # Stop stopping at 8 AM
  
  timezone: "America/New_York"    # Timezone for scheduling
  
  # Alternative: Same-day window
  # start: "22:00"               # 10 PM
  # end: "06:00"                 # 6 AM
```

**Timezone Options:**
- `UTC` (default)
- `America/New_York`
- `Europe/London`
- `Asia/Tokyo`
- And many more...

### RDS Instance Protection
```yaml
rds:
  # Engine types to exclude
  excluded_engines:
    - "aurora"                    # Aurora clusters
    - "aurora-mysql"
    - "aurora-postgresql"
  
  # Instance classes to exclude
  excluded_classes:
    - "db.r5.24xlarge"           # Very large instances
    - "db.m5.24xlarge"
```

## 💰 Cost Configuration

### Alert Thresholds
```yaml
cost:
  daily_report: true              # Enable daily cost reports
  alert_threshold_usd: 100       # Daily cost alert threshold
  monthly_alert_threshold_usd: 1000  # Monthly cost alert threshold
  
  # Alert recipients
  alert_recipients:
    - "admin@company.com"
    - "finance@company.com"
    - "devops@company.com"
```

### Cost Analysis
```yaml
cost:
  # Cost center tags for analysis
  cost_center_tags:
    - "CostCenter"
    - "Project"
    - "Department"
    - "Team"
    - "Environment"
  
  # Reporting periods
  reporting:
    daily: true                   # Daily cost reports
    weekly: true                  # Weekly summaries
    monthly: true                 # Monthly analysis
```

### Budget Integration
```yaml
cost:
  # AWS Budgets integration
  budgets:
    enabled: true
    check_frequency: "daily"      # daily, weekly, monthly
    
  # Cost anomaly detection
  anomaly_detection:
    enabled: true
    sensitivity: "medium"         # low, medium, high
    threshold_multiplier: 3       # Alert if cost > 3x average
```

## 📧 Email Configuration

### SMTP Settings
```yaml
email:
  smtp_server: "smtp.gmail.com"   # SMTP server address
  smtp_port: 587                  # SMTP port (587 for TLS)
  username: "your-email@gmail.com"
  password: "your-app-password"   # App password, not regular password
  from_address: "aws-cost-saver@company.com"
  use_tls: true                   # Enable TLS encryption
```

**Popular SMTP Providers:**

**Gmail:**
```yaml
email:
  smtp_server: "smtp.gmail.com"
  smtp_port: 587
  use_tls: true
```

**Outlook/Office365:**
```yaml
email:
  smtp_server: "smtp-mail.outlook.com"
  smtp_port: 587
  use_tls: true
```

**Amazon SES:**
```yaml
email:
  smtp_server: "email-smtp.us-east-1.amazonaws.com"
  smtp_port: 587
  use_tls: true
```

### Email Templates
```yaml
email:
  # Custom email templates
  templates:
    cost_report: "config/email_template.html"
    cost_alert: "config/alert_template.html"
    summary: "config/summary_template.html"
  
  # Email formatting
  format: "html"                  # html or text
  include_attachments: true       # Include CSV/JSON reports
```

## 📝 Logging Configuration

### Log Levels and Rotation
```yaml
logging:
  level: "INFO"                   # DEBUG, INFO, WARNING, ERROR, CRITICAL
  max_log_files: 10               # Maximum log files to keep
  max_log_size_mb: 10             # Maximum log file size
  
  # Log format
  format: "%(asctime)s - %(levelname)s - %(message)s"
  
  # Log destinations
  destinations:
    - "file"                      # Log to files
    - "console"                   # Log to console
    - "syslog"                    # Log to syslog (optional)
```

### Log File Management
```yaml
logging:
  # Log file naming
  filename_pattern: "{script}_{timestamp}.log"
  
  # Log retention
  retention_days: 30              # Keep logs for 30 days
  
  # Log compression
  compress_old_logs: true         # Compress old log files
  
  # Log archiving
  archive_logs: true              # Archive logs to S3 (optional)
  archive_bucket: "company-logs"  # S3 bucket for archiving
```

## 🛡️ Safety Configuration

### Confirmation and Protection
```yaml
safety:
  require_confirmation: false     # Require user confirmation
  max_instances_per_run: 50      # Limit instances per execution
  max_volumes_per_run: 100       # Limit volumes per execution
  backup_before_delete: true      # Create backups before deletion
  
  # Resource limits
  limits:
    max_daily_instances: 200      # Maximum instances per day
    max_daily_volumes: 500        # Maximum volumes per day
    max_daily_snapshots: 100      # Maximum snapshots per day
```

### Rollback and Recovery
```yaml
safety:
  # Rollback capabilities
  rollback:
    enabled: true                 # Enable rollback functionality
    max_rollback_hours: 24       # Maximum time for rollback
    create_restore_points: true   # Create restore points
  
  # Resource protection
  protection:
    production_environment: true  # Extra protection for production
    critical_resources: true      # Protect critical resources
    business_hours: true          # Respect business hours
```

## 🔔 Notification Configuration

### Multiple Notification Channels
```yaml
notifications:
  # Slack integration
  slack:
    enabled: true
    webhook_url: "https://hooks.slack.com/services/..."
    channel: "#aws-costs"
    username: "AWS Cost Saver"
    icon_emoji: ":money_with_wings:"
  
  # Microsoft Teams integration
  teams:
    enabled: true
    webhook_url: "https://company.webhook.office.com/..."
    title: "AWS Cost Alert"
  
  # Discord integration
  discord:
    enabled: true
    webhook_url: "https://discord.com/api/webhooks/..."
    username: "AWS Cost Monitor"
```

### Notification Preferences
```yaml
notifications:
  # When to send notifications
  triggers:
    cost_threshold_exceeded: true
    resource_cleanup: true
    error_occurred: true
    daily_summary: true
  
  # Notification frequency
  frequency:
    immediate: true               # Send immediately for critical alerts
    daily: true                  # Daily summary
    weekly: true                 # Weekly summary
    monthly: true                # Monthly summary
```

## ⏰ Schedule Configuration

### Automated Execution
```yaml
schedule:
  # Daily operations
  stop_idle_instances: "0 2 * * *"      # 2 AM daily
  clean_ebs_volumes: "0 3 * * *"        # 3 AM daily
  daily_cost_report: "0 8 * * *"        # 8 AM daily
  cost_alert: "0 9 * * *"               # 9 AM daily
  
  # Weekly operations
  cleanup_snapshots: "0 4 * * 0"        # Sunday 4 AM
  weekly_summary: "0 10 * * 1"          # Monday 10 AM
  
  # Business hours operations
  optimize_rds: "0 18 * * 1-5"          # Weekdays 6 PM
  start_rds: "0 8 * * 1-5"             # Weekdays 8 AM
```

**Cron Format:**
```
┌───────────── minute (0 - 59)
│ ┌───────────── hour (0 - 23)
│ │ ┌───────────── day of month (1 - 31)
│ │ │ ┌───────────── month (1 - 12)
│ │ │ │ ┌───────────── day of week (0 - 6) (Sunday=0)
│ │ │ │ │
* * * * *
```

### Time Zone Considerations
```yaml
schedule:
  timezone: "America/New_York"    # Schedule timezone
  
  # Business hours (local time)
  business_hours:
    start: "09:00"                # 9 AM local time
    end: "17:00"                  # 5 PM local time
    timezone: "America/New_York"
```

## 🔧 Advanced Configuration

### Environment-Specific Configs
```yaml
# Development environment
development:
  ec2:
    idle_threshold_hours: 2       # More aggressive in dev
    dry_run: false                # Allow actual changes
  
  safety:
    require_confirmation: false   # No confirmation needed
    max_instances_per_run: 100    # Higher limits

# Production environment
production:
  ec2:
    idle_threshold_hours: 48      # More conservative in prod
    dry_run: true                 # Always dry-run first
  
  safety:
    require_confirmation: true    # Always confirm
    max_instances_per_run: 10     # Lower limits
```

### Custom Scripts and Hooks
```yaml
hooks:
  # Pre-execution hooks
  pre_execution:
    - "scripts/custom/pre_check.py"
    - "scripts/custom/backup_state.py"
  
  # Post-execution hooks
  post_execution:
    - "scripts/custom/notify_team.py"
    - "scripts/custom/update_dashboard.py"
  
  # Error handling hooks
  on_error:
    - "scripts/custom/error_notification.py"
    - "scripts/custom/rollback.py"
```

### Integration Settings
```yaml
integrations:
  # AWS Systems Manager
  ssm:
    enabled: true
    document_name: "AWS-CostSaver"
    automation_role: "arn:aws:iam::123456789012:role/CostSaverAutomation"
  
  # AWS Lambda
  lambda:
    enabled: true
    function_name: "cost-saver-lambda"
    timeout: 300
  
  # AWS Step Functions
  step_functions:
    enabled: true
    state_machine: "cost-saver-workflow"
```

## 📊 Monitoring and Metrics

### CloudWatch Integration
```yaml
monitoring:
  cloudwatch:
    enabled: true
    namespace: "AWS/CostSaver"
    
    # Custom metrics
    metrics:
      - "InstancesStopped"
      - "VolumesDeleted"
      - "CostSavings"
      - "ErrorsOccurred"
  
  # Performance monitoring
  performance:
    track_execution_time: true
    track_api_calls: true
    track_resource_usage: true
```

### Health Checks
```yaml
health:
  # Health check endpoints
  endpoints:
    - "scripts/health_check.py"
    - "scripts/aws_connectivity.py"
    - "scripts/resource_availability.py"
  
  # Health check frequency
  frequency: "hourly"             # hourly, daily, weekly
  
  # Health check notifications
  notify_on_failure: true
  notify_on_degraded: true
```

## 🔐 Security Configuration

### Encryption and Security
```yaml
security:
  # Data encryption
  encryption:
    config_file: true             # Encrypt config file
    logs: true                    # Encrypt log files
    backups: true                 # Encrypt backup files
  
  # Access control
  access_control:
    require_authentication: true
    allowed_users: ["admin", "devops"]
    allowed_ips: ["10.0.0.0/8", "192.168.0.0/16"]
  
  # Audit logging
  audit:
    enabled: true
    log_all_actions: true
    log_config_changes: true
    log_access_attempts: true
```

## ✅ Configuration Validation

### Validation Commands
```bash
# Validate configuration file
python3 -c "
import yaml
with open('config/config.yaml', 'r') as f:
    config = yaml.safe_load(f)
print('Configuration is valid')
"

# Test AWS connectivity
python3 scripts/test_aws_connectivity.py

# Validate email configuration
python3 scripts/test_email_config.py
```

### Configuration Testing
```yaml
testing:
  # Test mode settings
  test_mode: true
  test_aws_account: "123456789012"
  test_region: "us-east-1"
  
  # Mock services for testing
  mock_services:
    - "ec2"
    - "rds"
    - "ce"
  
  # Test data
  test_data:
    instances: 5
    volumes: 10
    snapshots: 20
```

## 🔄 Configuration Updates

### Dynamic Configuration
```yaml
# Environment variables override
environment_overrides:
  AWS_REGION: "AWS_DEFAULT_REGION"
  COST_THRESHOLD: "COST_ALERT_THRESHOLD"
  EMAIL_RECIPIENTS: "COST_ALERT_RECIPIENTS"

# Configuration hot-reload
hot_reload:
  enabled: true
  check_interval: 300            # Check for changes every 5 minutes
  reload_on_change: true         # Automatically reload on change
```

### Configuration Versioning
```yaml
version: "1.0.0"
config_schema: "v1"
last_updated: "2024-01-01"

# Migration support
migrations:
  - from: "0.9.0"
    to: "1.0.0"
    script: "migrations/v0.9_to_v1.0.py"
```

This configuration guide covers all the major settings available in the AWS Cost Saver Pack. Remember to always test configuration changes in a non-production environment first!
