#!/bin/bash

# AWS Cost Saver Pack - Quick Start Script
# This script helps you get started quickly with the AWS Cost Saver Pack
#
# Tool created by: acnid.al@gmail.com
# Support the project: https://buymeacoffee.com/acnidal

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${BLUE}================================${NC}"
echo -e "${BLUE}  AWS Cost Saver Pack${NC}"
echo -e "${BLUE}  Quick Start Script${NC}"
echo -e "${BLUE}================================${NC}"
echo

# Function to check prerequisites
check_prerequisites() {
    echo -e "${YELLOW}Checking prerequisites...${NC}"
    
    # Check Python
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
        echo -e "${GREEN}✓ Python found: $PYTHON_VERSION${NC}"
    else
        echo -e "${RED}✗ Python 3 not found. Please install Python 3.7+${NC}"
        exit 1
    fi
    
    # Check AWS CLI
    if command -v aws &> /dev/null; then
        AWS_VERSION=$(aws --version 2>&1 | awk '{print $1}')
        echo -e "${GREEN}✓ AWS CLI found: $AWS_VERSION${NC}"
    else
        echo -e "${RED}✗ AWS CLI not found. Please install AWS CLI${NC}"
        echo "  Download from: https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html"
        exit 1
    fi
    
    # Check pip
    if command -v pip3 &> /dev/null; then
        echo -e "${GREEN}✓ pip3 found${NC}"
    else
        echo -e "${RED}✗ pip3 not found. Please install pip${NC}"
        exit 1
    fi
    
    echo
}

# Function to setup virtual environment
setup_virtual_env() {
    echo -e "${YELLOW}Setting up Python virtual environment...${NC}"
    
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        echo -e "${GREEN}✓ Virtual environment created${NC}"
    else
        echo -e "${GREEN}✓ Virtual environment already exists${NC}"
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    echo -e "${GREEN}✓ Virtual environment activated${NC}"
    
    # Upgrade pip
    pip install --upgrade pip
    echo -e "${GREEN}✓ pip upgraded${NC}"
    
    echo
}

# Function to install dependencies
install_dependencies() {
    echo -e "${YELLOW}Installing Python dependencies...${NC}"
    
    if [ -f "requirements.txt" ]; then
        pip install -r requirements.txt
        echo -e "${GREEN}✓ Dependencies installed${NC}"
    else
        echo -e "${RED}✗ requirements.txt not found${NC}"
        exit 1
    fi
    
    echo
}

# Function to check AWS configuration
check_aws_config() {
    echo -e "${YELLOW}Checking AWS configuration...${NC}"
    
    if aws sts get-caller-identity &> /dev/null; then
        ACCOUNT_ID=$(aws sts get-caller-identity --query 'Account' --output text)
        USER_ARN=$(aws sts get-caller-identity --query 'Arn' --output text)
        REGION=$(aws configure get region 2>/dev/null || echo "not set")
        
        echo -e "${GREEN}✓ AWS credentials configured${NC}"
        echo -e "  Account ID: $ACCOUNT_ID"
        echo -e "  User: $USER_ARN"
        echo -e "  Region: $REGION"
        
        if [ "$REGION" = "not set" ]; then
            echo -e "${YELLOW}⚠ Warning: AWS region not configured${NC}"
            echo -e "  Run: aws configure set region us-east-1"
        fi
    else
        echo -e "${RED}✗ AWS credentials not configured${NC}"
        echo -e "  Please run: aws configure"
        echo -e "  Or set environment variables:"
        echo -e "    export AWS_ACCESS_KEY_ID=your_access_key"
        echo -e "    export AWS_SECRET_ACCESS_KEY=your_secret_key"
        echo -e "    export AWS_DEFAULT_REGION=us-east-1"
        exit 1
    fi
    
    echo
}

# Function to setup configuration
setup_configuration() {
    echo -e "${YELLOW}Setting up configuration...${NC}"
    
    if [ ! -f "config/config.yaml" ]; then
        echo -e "${RED}✗ Configuration file not found${NC}"
        exit 1
    fi
    
    # Create logs directory
    mkdir -p logs
    echo -e "${GREEN}✓ Logs directory created${NC}"
    
    # Check if config needs customization
    if grep -q "your-email@gmail.com" config/config.yaml; then
        echo -e "${YELLOW}⚠ Configuration needs customization${NC}"
        echo -e "  Please edit config/config.yaml with your settings"
        echo -e "  At minimum, update:"
        echo -e "    - AWS region"
        echo -e "    - Email settings"
        echo -e "    - Cost thresholds"
    else
        echo -e "${GREEN}✓ Configuration appears to be customized${NC}"
    fi
    
    echo
}

# Function to test scripts
test_scripts() {
    echo -e "${YELLOW}Testing scripts (dry-run mode)...${NC}"
    
    # Test idle instance detection
    echo -e "Testing idle instance detection..."
    if python3 scripts/stop_idle_instances.py --dry-run --config config/config.yaml &> /dev/null; then
        echo -e "${GREEN}✓ Idle instance script working${NC}"
    else
        echo -e "${RED}✗ Idle instance script failed${NC}"
    fi
    
    # Test EBS cleanup
    echo -e "Testing EBS cleanup script..."
    if bash scripts/clean_unused_ebs.sh --dry-run &> /dev/null; then
        echo -e "${GREEN}✓ EBS cleanup script working${NC}"
    else
        echo -e "${RED}✗ EBS cleanup script failed${NC}"
    fi
    
    # Test cost reporting
    echo -e "Testing cost reporting script..."
    if python3 scripts/daily_cost_report.py --no-email --config config/config.yaml &> /dev/null; then
        echo -e "${GREEN}✓ Cost reporting script working${NC}"
    else
        echo -e "${RED}✗ Cost reporting script failed${NC}"
    fi
    
    echo
}

# Function to setup cron jobs
setup_cron() {
    echo -e "${YELLOW}Setting up automated execution...${NC}"
    
    echo -e "Would you like to set up automated execution with cron? (y/n)"
    read -r response
    
    if [[ "$response" =~ ^[Yy]$ ]]; then
        echo -e "Setting up cron jobs..."
        
        # Get absolute path
        ABSOLUTE_PATH=$(realpath "$SCRIPT_DIR")
        
        # Create cron entries
        CRON_ENTRIES=(
            "# AWS Cost Saver Pack - Automated Execution"
            "# Stop idle instances daily at 2 AM"
            "0 2 * * * cd $ABSOLUTE_PATH && source venv/bin/activate && python3 scripts/stop_idle_instances.py >> logs/cron.log 2>&1"
            "# Clean unused EBS volumes daily at 3 AM"
            "0 3 * * * cd $ABSOLUTE_PATH && bash scripts/clean_unused_ebs.sh >> logs/cron.log 2>&1"
            "# Generate daily cost report at 8 AM"
            "0 8 * * * cd $ABSOLUTE_PATH && source venv/bin/activate && python3 scripts/daily_cost_report.py >> logs/cron.log 2>&1"
            "# Clean up old snapshots weekly on Sunday at 4 AM"
            "0 4 * * 0 cd $ABSOLUTE_PATH && source venv/bin/activate && python3 scripts/cleanup_snapshots.py >> logs/cron.log 2>&1"
        )
        
        # Check if cron jobs already exist
        if crontab -l 2>/dev/null | grep -q "AWS Cost Saver Pack"; then
            echo -e "${YELLOW}⚠ Cron jobs already exist${NC}"
            echo -e "  Current cron jobs:"
            crontab -l 2>/dev/null | grep -A 10 "AWS Cost Saver Pack" || true
        else
            # Add to existing crontab or create new one
            (crontab -l 2>/dev/null; printf '%s\n' "${CRON_ENTRIES[@]}") | crontab -
            echo -e "${GREEN}✓ Cron jobs configured${NC}"
        fi
        
        echo -e "  Cron jobs will run automatically"
        echo -e "  Check logs/cron.log for execution details"
    else
        echo -e "${YELLOW}⚠ Automated execution not configured${NC}"
        echo -e "  You can set it up later manually"
    fi
    
    echo
}

# Function to show next steps
show_next_steps() {
    echo -e "${GREEN}================================${NC}"
    echo -e "${GREEN}  Setup Complete! 🎉${NC}"
    echo -e "${GREEN}================================${NC}"
    echo
    
    echo -e "${BLUE}Next Steps:${NC}"
    echo -e "1. ${YELLOW}Customize configuration:${NC}"
    echo -e "   - Edit config/config.yaml"
    echo -e "   - Set your email settings"
    echo -e "   - Adjust cost thresholds"
    echo -e "   - Configure AWS region"
    echo
    
    echo -e "2. ${YELLOW}Test the scripts:${NC}"
    echo -e "   - python3 scripts/stop_idle_instances.py --dry-run"
    echo -e "   - bash scripts/clean_unused_ebs.sh --dry-run"
    echo -e "   - python3 scripts/daily_cost_report.py --no-email"
    echo
    
    echo -e "3. ${YELLOW}Run in production:${NC}"
    echo -e "   - Remove --dry-run flags"
    echo -e "   - Monitor logs/ directory"
    echo -e "   - Check email notifications"
    echo
    
    echo -e "4. ${YELLOW}Monitor and optimize:${NC}"
    echo -e "   - Review cost savings"
    echo -e "   - Adjust thresholds as needed"
    echo -e "   - Set up additional alerts"
    echo
    
    echo -e "${BLUE}Documentation:${NC}"
    echo -e "  - README.md - Main documentation"
    echo -e "  - docs/SETUP.md - Detailed setup guide"
    echo -e "  - docs/CONFIGURATION.md - Configuration options"
    echo -e "  - docs/TROUBLESHOOTING.md - Common issues"
    echo
    
    echo -e "${BLUE}Support:${NC}"
    echo -e "  - Check logs/ directory for execution details"
    echo -e "  - Review troubleshooting guide for common issues"
    echo -e "  - Test in non-production environment first"
    echo
    
    echo -e "${GREEN}Happy cost saving! 💰${NC}"
}

# Function to show Docker option
show_docker_option() {
    echo -e "${YELLOW}Docker Alternative:${NC}"
    echo -e "  If you prefer containerized deployment:"
    echo -e "  - docker-compose up -d"
    echo -e "  - docker exec -it aws-cost-saver bash"
    echo
}

# Main execution
main() {
    echo -e "${BLUE}Welcome to AWS Cost Saver Pack!${NC}"
    echo -e "This script will help you set up the cost optimization tools."
    echo
    
    # Check prerequisites
    check_prerequisites
    
    # Setup virtual environment
    setup_virtual_env
    
    # Install dependencies
    install_dependencies
    
    # Check AWS configuration
    check_aws_config
    
    # Setup configuration
    setup_configuration
    
    # Test scripts
    test_scripts
    
    # Setup cron jobs
    setup_cron
    
    # Show Docker option
    show_docker_option
    
    # Show next steps
    show_next_steps
}

# Run main function
main "$@"
